//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------Event-Listeners-----------------------------------------------------------------------------//

document.addEventListener("DOMContentLoaded", function() { //when the document is loaded //setup event listener when DOM is loaded
    var registerButton = document.getElementById("registerButton"); //get register button from HTML

    registerButton.addEventListener("click", function() { //event listener for register button
        console.log("Register button is clicked");//debug
        register();
    })
});


//------------------------------------------------------------------------------------------------------------------------------------------------------------//

function register() {
    var firstName = document.getElementById("firstName").value; //get values from HTML registration form
    var lastName  = document.getElementById("lastName").value;
    var birthDate = document.getElementById("birthDate").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    var alertMessage = document.getElementById("ErrorAlert");

    alertMessage.innerHTML = ""; //clear all previous alerts

    if (!firstName || !lastName || !birthDate || !email || !password) { //check if any of required fields are empty
        alertMessage.innerHTML = "All fields are required"; //if any of required fields are empty, display error message and return
        return;
    }

    if(!emailValidation(email)) { //call email validation function to check if email is valid
        alertMessage.innerHTML = "Invalid email address"; //if email is not valid, display error message and return
        return;
    }

    if(password != confirmPassword) { //check if passwords match
        alertMessage.innerHTML = "Passwords do not match"; //if passwords do not match, display error message and return
        return;
    }


    fetch ("http://localhost:3001/api/register", { //make a POST request
        method: "POST", //specify POST method
        headers:{
            "Content-Type": "application/json" //specify JSON content type
        },
        body: JSON.stringify({ //convert all data to JSON string
            firstName: firstName,
            lastName: lastName,
            birthDate: birthDate,
            email: email,
            password: password
        })
    })
    .then(response => response.text()) //convert response to text
    .then(text => {
        //console.log(text); //debug
        if(text == "Registration successful") { //handle server response based on text
            //console.log("Redirecting to index.html"); //debug
            alert("Registration successful! You are being redirected to the login page."); //display success message and redirect
            setTimeout(function() {
                window.location.href = "../index.html";
            }, 1000);
        }
        else{
            if(text == "Email already exists") { //handle a specific server response
                alertMessage.textContent = "Email already exists"; //show alert if email already exists
            }
            else {
                alertMessage.textContent = "Registration failed: " + text; //show alert if registration failed
            }
        }
    })
    .catch(error => {
        console.log(error); //debug
        alertMessage.textContent = "Error, please try again later. (server je crko)";  //show alert for server error
    });
}


function emailValidation(email) { //utility function to check if email is valid
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email); //function returns true if email is valid or false if not
}