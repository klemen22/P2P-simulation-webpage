const itemsPerPage = 10; //number of items to display per page
let totalPages = 1;
let currentPage = 1;
let filters = {ip: "", startDate: "", endDate: ""}; //object to store filters

function fetchData(page = 1) { //function to fetch data from server with specific filters
    axios.get("http://localhost:3001/api/addresses", {
        params: {
            ip: filters.ip, //ip filter value
            start: filters.startDate, //start date filter value
            end: filters.endDate, //end date filter value
            page, //page number
            itemsPerPage //number of items to display per page
        }
    })
    .then(response => {
        const data = response.data; //get data from response
        totalPages = data.totalPages; //update total number of pages
        currentPage = page; // update currentPage number
        updateTable(data.results); //update table with fetched data
        updatePagination(page, totalPages); //update pagination controls with fetched data
        toggleResetButton(); //toggle reset button //show or hide reset button
    })
    .catch(error => {
        console.error("Error fetching data:", error); //debug
    });
}

function updateTable(data) { //following function updates table with fetched data
    return new Promise((resolve, reject) => {
        const tableBody = document.getElementById("tableBody"); //retrieve table body from HTML
        tableBody.innerHTML = ''; //clear existing rows

        data.forEach(item => { //loop through fetched data and create table rows //.forEach() is used to iterate over an array and it works similarly to for loop
            const row = document.createElement("tr"); //get table row -> 'tr' == table row >:( also dont forget 'td' == table data >:(
            row.innerHTML =`
                <td>${item.id}</td>
                <td>${item.ipAddress}</td>
                <td>${formatDate(item.timeStamp)}</td>`; //additonal function added for formatting date and time
            tableBody.appendChild(row); //append row to table body so it doesn't overwrite other rows
        });

        resolve(); //resolve promise when table is updated
    });
}

function formatDate(timeStamp) { //utility function for formating date and time into more human-friendly format
    const date = new Date(timeStamp);
    const options = { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', hour12: false };
    return date.toLocaleDateString('en-GB', options).replace(',', ''); //convert date to english format and remove commas
}

function updatePagination(page, totalPages) { //following function updates pagination controls based on current page and total number of pages
    return new Promise((resolve, reject) => {
        const pageNumber = document.getElementById("pageNumber"); //retrieve page number from HTML
        pageNumber.textContent = `${page} of ${totalPages}`; //update page number display
        document.querySelector('button[onclick="previousPage()"]').disabled = page === 1; //disable previous button if current page is 1
        document.querySelector('button[onclick="nextPage()"]').disabled = page === totalPages; //disable next button if current page is equal to total number of pages
        resolve();
    });
}

function previousPage() { //following function calls fetchData function to fetch data for the previous page
    if (currentPage > 1) {
        fetchData(currentPage - 1);
    }
}

function nextPage() { //following function calls fetchData function to fetch data for the next page
    if (currentPage < totalPages) {
        fetchData(currentPage + 1);
    }
}

function toggleResetButton(){ //following function toggles reset button based on presence of filters
    const ResetButton = document.getElementById("ResetButton"); //retrieve reset button from HTML
    if(filters.ip || filters.startDate || filters.endDate){
        ResetButton.style.display = "inline-block"; //show reset button if filters are applied
    }
    else{
        ResetButton.style.display = "none"; //hide display button
    }
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------Event-Listeners-----------------------------------------------------------------------------//
addEventListener('DOMContentLoaded', function() { //when the document is loaded
    var FilterButton = document.getElementById("FilterButton"); //get filter button
    var BackButton = document.getElementById("BackButton"); //get back button
    var ResetButton = document.getElementById("ResetButton"); //get reset button

    fetchData(); //initial fetch data without filters

    BackButton.addEventListener("click", function() { //add event listener for back button to redirect back to main page
        window.location.href = "../html/test.html"; //redirect back to main page
    });

    FilterButton.addEventListener("click", function() { //add event listener for filter button to apply filters
        filters.ip = document.getElementById("searchIp").value; //update filters object with values from filter inputs
        filters.startDate = document.getElementById("startDate").value;
        filters.endDate = document.getElementById("endDate").value;
        fetchData(1); // Fetch data with filters applied, starting from the first page
    });

    ResetButton.addEventListener("click", function() { //add event listener for reset button to clear filters and fetch data without filters
        document.getElementById("searchIp").value = ""; //clear filter inputs
        document.getElementById("startDate").value = "";
        document.getElementById("endDate").value = "";
        filters = {ip: "", startDate: "", endDate: ""}; //clear filters object
        fetchData(1); // fetch data with cleared filters, starting from the first page
    });
});

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
