//short test script for hashing passwords
const bcrypt = require("bcrypt"); //import bcrypt module for hashing and comparing passwords
const saltRounds = 10; //set number of rounds for hashing
const readline = require("readline"); //import readline module for reading user input from console

const rl = readline.createInterface({ //create readline interface
    input: process.stdin, //standard input stream
    output: process.stdout //standard output stream
});

rl.question("Enter password: ", (password) => { //ask user for password
    bcrypt.hash(password, saltRounds, function(err, hash) { //hash password
        if(err) { //handle error
            console.error("Error hashing password:", err); //debug
            rl.close(); //close readline interface
            return;
        }
        console.log("Hashed password:", hash); //print hashed password
        rl.close(); //close readline interface
    });
});