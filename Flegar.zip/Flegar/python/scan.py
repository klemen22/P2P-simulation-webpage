# import required modules
import time as t #import time module
import subprocess as sub #import subprocess module

while True: #create infinite loop :)
    comanda = 'Get-Process' #define command to get list of running processes
    r = sub.run(['powershell', '-Command', comanda], capture_output=True, text=True) #run powershell command
    print(r.stdout) #display output
    comanda = 'Get-Service' #define command to get list of running services
    r = sub.run(['powershell', '-Command', comanda], capture_output=True, text=True) #run powershell command
    print(r.stdout) #display output
    tshark_command = ( #define tshark command
        "$PSDefaultParameterValues = @{'Out-File:Encoding' = 'utf8'}; " #set encoding to utf8
        "tshark -i Ethernet -f 'portrange 6881-6889' -T ek -e ip.src -e ip.dst -e ip.ttl -c 20 " 
        "> C:\\xampp\\htdocs\\Flegar\\captured_packets\\capture.json" #Tshark command
    )
    r = sub.run(['powershell', '-Command', tshark_command], capture_output=True, text=True) #run powershell with tshark command
    print(r.stdout) #display output
    t.sleep(120) #wait 120 seconds
