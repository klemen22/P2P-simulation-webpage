var delay = 400;
var radius = 400;
var completed = false;
var IntervalTime = 20000; //predefined interval time in ms
var sevrerAnimationInterval; //variable for interval id
var stopBtn = false; //flag for stop button
var startBtn = false; //flag for start button
var stunPackets; //variable for stun packets
var trackerPackets; //variable for tracker packets


//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------Initial_Draw--------------------------------------------------------------------------------//

function InitialDraw() {
    var container = document.getElementById('container_hole_punching'); //get container id from html
    var nodesMain = new vis.DataSet([]);
    var edgesMain = new vis.DataSet([]);
    var data = {nodes: nodesMain, edges: edgesMain}; //combine nodes and edges into a data object
    var i = 0; //counter for nodes
    var j = 0; //counter for edges
    var serverCounter = 0; //simple counter to distinguish between STUN and Tracker servers

    var options = { //options object for network - part of the vis.js library
        height: '100%',
        width: '100%',
        physics: {
            forceAtlas2Based: {
              gravitationalConstant: -200,
              centralGravity: 0.005,
              springLength: 200,
              springConstant: 0.18,
            },
            maxVelocity: 400,
            solver: "forceAtlas2Based",
            timestep: 0.1,
            stabilization: false,
          },
    };

    //console.log("InitialDraw start"); //debug
    function NodeGeneration (){ //following function generates nodes for simulation
        return new Promise((resolve, reject) => { //function is based on a promise for asynchronous execution
            function addNode(){ //following function loops for animation like effect
                if(i < 3){ //generate first 3 peer nodes 
                    var angle = i *  2 * Math.PI / 3; //angle of node
                    var x = (radius + 100) * Math.cos(angle); //x coordinate
                    var y = (radius + 100) * Math.sin(angle); //y coordinate
                    //console.log("Node:",i, "x:", x, "y:", y);//debug
                    nodesMain.add({ //node object
                        id: i,
                        label: 'Peer ' + (i + 1) , //label for normal peer nodes: Peer 1, Peer 2, Peer 3
                        x: x,
                        y: y,
                        color: {background: '#f2f2f2', border: '#f2f2f2', highlight: {background: '#f2f2f2', border: '#f2f2f2'}},
                        shape: 'circle',
                        size: 10,
                        physics: false
                    });
                    i++;
                    setTimeout(addNode, delay); //delay for animation
                }
                else if(2 < i  && i < 6){ //generate 3 router nodes
                    var angle = i *  2 * Math.PI / 3; //angle of node
                    var x = (radius - 100) * Math.cos(angle); //x coordinate
                    var y = (radius - 100) * Math.sin(angle); //y coordinate
                    //console.log("Node:",i, "x:", x, "y:", y);//debug
                    nodesMain.add({ //node object
                        id: i,
                        label: 'Router ' + (i - 2) , //label for router nodes: Router 1, Router 2, Router 3
                        x: x,
                        y: y,
                        color: {background: '#fe0e74', border: '#fe0e74', highlight: {background: '#fe0e74', border: '#fe0e74'}},
                        shape: 'triangle',
                        size: 30,
                        fixed: {x: true, y: true},
                        physics: false,
                        font: {color: '#f2f2f2'}
                    });
                    i++;
                    setTimeout(addNode, delay); //delay for animation
                }
                else if(5 < i && i < 8){ //generate 2 server nodes (STUN and Tracker)
                    var angle = (i + 1) *  2 * Math.PI/2 ; //angle of node
                    var x = (radius - 300) * Math.cos(angle); //x coordinate
                    var y = (radius - 300) * Math.sin(angle); //y coordinate
                    //console.log("Node:",i, "x:", x, "y:", y);//debug

                    var label;

                    if(serverCounter == 0){
                        label = 'STUN Server';
                    }
                    else{
                        label = 'Tracker Server';
                        y = y + 100; //small offset so that the connections dont overlap
                    }

                    nodesMain.add({
                        id: i,
                        label: label,
                        x: x,
                        y: y,
                        color: {background: '#09ea92', border: '#09ea92', highlight: {background: '#09ea92', border: '#09ea92'}},
                        shape: 'square',
                        size: 30,
                        physics: false,
                        font: {color: '#f2f2f2'}
                    });
                    serverCounter++;
                    i++;
                    setTimeout(addNode, delay); //delay for animation
                    
                }
                else{
                    completed = true;
                    resolve(); //resovle the promise when all nodes are generated
                }
            }
            addNode();
        })
    };

    //NodeGeneration();

    function EdgeGeneration(){ // following function generates edges between peer nodes coresponding router nodes
        NodeGeneration().then(() => { //wait for NodeGeneration to finish
            //console.log("EdgeGeneration start"); //debug
            var addEdge = () => { //generate edges between peer nodes coresponding router nodes
                if(j < 3){
                   //console.log("Edge:", j, j + 3); //debug 
                   edgesMain.add({id: j,from: j, to: j + 3, dashes: true, physics: false, color:{color: '#f2f2f2'}, width: 1}); 
                   j++;
                   setTimeout(addEdge, delay); //delay for animation
                }
                else{
                    completed = true;
                    //console.log("Completed status:", completed);
                    network.fit({ //fit the network to the container
                        animation: {
                            duration: 1000,
                            easingFunction: 'easeInOutQuad'
                        }
                    });
                }
            };
            addEdge(); //initial call of addEdge()
        });
    }

    EdgeGeneration(); //start node and edge generation
    network = new vis.Network(container, data, options); //initialize the network

}

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------Event-Listeners-----------------------------------------------------------------------------//

document.addEventListener("DOMContentLoaded", function() { //when the document is loaded
    var delay = 400;
    var SimulateButton = document.getElementById("SimulateButton"); //reference to simulate button
    var StopButton = document.getElementById("StopButton"); //reference to stop button

   //console.log("Completed status:", completed); //debug
    setTimeout(InitialDraw, delay); //perform initial draw after a short delay (400 ms)
  
    fetchData("../example_packets/stun_server.json").then((data) => { //fetch stun packets from json file with given path
        stunPackets = data;
        //console.log("stunPackets:", stunPackets); //debug
    })
    .catch(error => {
        console.error("Failed to fetch data:", error); //log any errors
    });

    fetchData("../example_packets/tracker.json").then((data) => { //fetch tracker packets from json file with given path
        trackerPackets = data;
        //console.log("trackerPackets:", trackerPackets); //debug
    })
    .catch(error => {
        console.error("Failed to fetch data:", error); //log any errors
    });

    SimulateButton.addEventListener("click", function() { //event listener for simulate button

        if(completed == true){ //check if simulation is completed //if initial draw is completed
            stopBtn = false; //update flag for stop button
            startBtn = true; //update flag for start button
            completed = false; //update flag for completed status
            //console.log("Start button value:", startBtn); //debug	
            //console.log("Simulate button is clicked"); //debug
            //console.log("Completed status:", completed); //debug
            updateLog("<span class = 'highlight'>Simulation Started</span>"); //update simulation log with start message
            resetEdgeColorPeer().then(() => { //reset edges between peer nodes
                resetEdgeColorServer().then(() => { //reset edges between peer, router and server nodes
                    completeAnimation(); //start complete animation
                })
            })

        }
    });

    StopButton.addEventListener("click", function() { //event listener for stop button
        if(startBtn == true){
            stopBtn = true; //update flag for stop button to stop the animation
            //console.log("Stop button is clicked"); //debug
            completed = true; //update flag for completed status
            updateLog("<span class = 'highlight'>Simulation Stopped</span>"); //update simulation log with stop message
        }

        //console.log("Stop button value:", stopBtn); //debug
    });

});

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------------------------Server-interaction---------------------------------------------------------------------//

function ServerAnimation(){ //following function simulates the interaction between peer nodes and STUN and Tracker servers
    return new Promise((resolve, reject) => { //based on a promise for asynchronous execution
        ServerInteraction("STUN").then(() => { //simulate interaction between peer nodes and STUN server
            return DelayFunction(800);
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';} //added additional check for stop button for better responsiveness //animation is stopped with thrown error
            return ServerInteraction("Tracker"); //simulate interaction between peer nodes and Tracker server
        })
        .then(() => {
            return DelayFunction(800); //delay for animation
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';}
            return stopServerInterval(); //stop server interval //interval was added to prevent overlapping of animation
        })
        .then(() => {
            resolve()
        })
        .catch((error) => {
            if(error == 'Animation stopped'){ 
                //console.log("Animation stopped"); //debug
                resolve(); //if animation is stopped, resolve the promise
            }
            else{
                console.log(error); //debug
                reject(error);
            }
        });
    })

};

function startServerInterval(){ //function to start server interval
    if(! sevrerAnimationInterval){
        sevrerAnimationInterval = setInterval(() => {
           ServerAnimation(); 
        }, IntervalTime);
    }
}

function stopServerInterval(){ //function to stop server interval
    if(sevrerAnimationInterval){
        clearInterval(sevrerAnimationInterval); //clear the interval
        sevrerAnimationInterval = null;
    }
}

function ServerInteraction(targetServer){ //functio that handles the interaction between peer nodes and targetServer //targetServer = "STUN" or "Tracker"
    return new Promise((resolve, reject) => {
        //var allNodes = network.body.data.nodes.getIds();
        //var allEdges = network.body.data.edges.getIds();
        //console.log("ServerInteraction() is called, targetServer:", targetServer);
        //console.log("All nodes:", allNodes); //debug
        //console.log("All edges:", network.body.data.edges); //debug
        //console.log("Selected edge:", allEdges[0], "is connected to nodes:", network.body.data.edges.get(allEdges[0]).from,"and",network.body.data.edges.get(allEdges[0]).to); //debug
    
        connectToRouter("forward").then(() => { //simulate peer nodes connecting to corresponding router nodes
            return DelayFunction(800); //delay for animation
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';} //added additional check for stop button for better responsiveness
            return connectToServer("forward", targetServer); //simulate router nodes connecting to corresponding server nodes
        })
        .then(() => {
            return DelayFunction(800); //delay for animation
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';}
            return resetEdgeColorServer(); //restore inital edges between peers and coresponding router nodes to default color and remove other edges
        })
        .then(() => {
            return DelayFunction(1000); //delay for animation
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';}
            return connectToServer("backward", targetServer); //simulate server nodes connecting to corresponding router nodes
        })
        .then(() => {
            return DelayFunction(800); //delay for animation
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';}
            return connectToRouter("backward", targetServer); //simulate router nodes connecting to corresponding peer nodes
        })
        .then(() => {
            return DelayFunction(800); //delay for animation
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';}
            return resetEdgeColorServer(); //restore inital edges between peers and coresponding router nodes to default color and remove other edges
        })
        .then(() => {
            resolve();
        })
        .catch((error) => {
            if(error == 'Animation stopped'){
                console.log("Animation stopped");
                resolve(); //if stop button is pressed, resolve the promise
            }
            else{
                console.log(error);
                reject(error);
            }
        });
    });
}

function DelayFunction(delayMS){ //utility function to delay the animation
    return new Promise((resolve, reject) => {
        setTimeout(resolve, delayMS);
    });
}

function resetEdgeColorServer(){ //folllowing function resets edges between peer, router and server nodes
    return new Promise((resolve, reject) => {
        //console.log("resetEdgeColorServer() is called");
        var allEdges = network.body.data.edges.getIds(); //retrieve all edges fro network
        var edgesToUpdate = [];
        //console.log("All edges:", allEdges);

        for(var j = 0; j < allEdges.length; j++){ //remove all STUN and Tracker edges
            if((typeof allEdges[j] === 'string' && allEdges[j].startsWith("STUN")) || (typeof allEdges[j] === 'string' && allEdges[j].startsWith("Tracker"))){
                network.body.data.edges.remove(allEdges[j]);
            }
        }

        for(var i = 0; i < 3; i++){ //restore inital edges between peers and coresponding router nodes
            edgesToUpdate.push({
                id: allEdges[i],
                dashes: true,
                color: {color: '#f2f2f2'},
                width: 1,
                arrows:{
                    to:{
                        enabled: false
                    },
                    from:{
                        enabled: false
                    }
                }
            })
        }


        network.body.data.edges.update(edgesToUpdate); //update edges
        resolve(); //resolve promise when all edges are updated
    });
}


function resetEdgeColorPeer(){ //folllowing function resets edges between peer nodes
    return new Promise((resolve, reject) => {
        //console.log("resetEdgeColorPeer() is called");
        var allEdges = network.body.data.edges.getIds(); //get all edges from network
        //console.log("All edges:", allEdges); //debug

        for(var j = 0; j < allEdges.length; j++){ //remove all toSeed, toLeech and down edges
            if((typeof allEdges[j] === 'string' && allEdges[j].startsWith("toSeed")) || (typeof allEdges[j] === 'string' && allEdges[j].startsWith("toLeech")) || (typeof allEdges[j] === 'string' && allEdges[j].startsWith("down"))){
                network.body.data.edges.remove(allEdges[j]);
            }
        }

        resolve(); //resolve promise when all edges are updated
    });
}

function connectToRouter(direction){ //following function simulates establishing connection between peer nodes and router nodes based on direction
    return new Promise((resolve, reject) => {
        //console.log("connectToRouter() is called");
        var allEdges = network.body.data.edges.getIds(); //retrieve all edges from network
        var edgesToUpdate = []; //empty array to store edges to be updated

        switch(direction){ //update edges based on direction
            case "forward":{
                for(var i = 0; i < 3; i++){
                    edgesToUpdate.push({ //edge object
                        id: allEdges[i],
                        dashes: false,
                        color: {color: '#f2f2f2'},
                        width: 2,
                        arrows:{
                            to:{
                                enabled: true,
                                type: 'arrow',
                                scaleFactor: 1
                            }
                        },
                        endPointOffset:{to: 0}
                    });
                };
                break;
            };
            case "backward":{
                for(var i = 0; i < 3; i++){
                    edgesToUpdate.push({ //edge object
                        id: allEdges[i],
                        dashes: false,
                        color: {color: '#f2f2f2'},
                        width: 2,
                        arrows:{
                            from:{
                                enabled: true,
                                type: 'arrow',
                                scaleFactor: 1
                            }
                        },
                        endPointOffset:{to: 0}
                    });
                };
                break;
            };
            default:
                //console.log("Error in connectToRouter()");
        }


        network.body.data.edges.update(edgesToUpdate); //update edges
        resolve(); //resolve promise when all edges are updated
    });
}

function connectToServer(direction, type){ //following function simulates establishing connection between router nodes and server nodes based on direction and server target
    return new Promise((resolve, reject) => {
        var allEdges = network.body.data.edges.getIds(); //retrieve all edges from network
        //console.log("All edges:", allEdges); //debug
        var target = 6; //id of trageted node for connection - 6 is default value

        switch(type){ //determin target node based on type of server
            case "STUN":{
                target = 6;
                break;
            }
            case "Tracker":{
                target = 7;
                break;
            }
            default:{
                console.log("Error with type of serever in connectToServer()"); //debug
            }
        }

        switch(type){ //log the interaction details with updateLog() function and captured packets
            case "STUN":{ //log details for STUN
                if(direction == "forward"){ //contents of packets that are sent to STUN server
                    updateLog("STUN request: " + "<br>&emsp;Packet type: " + stunPackets[0]._source.layers.stun["stun.type"]);
                    break;
                }
                if(direction == "backward"){ //contents of packets that are received from STUN server
                    updateLog("STUN response: "+ "<br>&emsp;Packet type: " + stunPackets[1]._source.layers.stun["stun.type"] + "<br>&emsp;ip: " + stunPackets[1]._source.layers.stun["stun.attributes"]["stun.attribute_tree"]["stun.att.ipv4"] + "<br>&emsp;port: " + stunPackets[1]._source.layers.stun["stun.attributes"]["stun.attribute_tree"]["stun.att.port"]);
                    break
                }
            }
            case "Tracker":{ //log details for Tracker
                if(direction == "forward"){ //contents of packets that are sent to Tracker server	
                    updateLog("Tracker request:" 
                        + "<br>&emsp;Packet type: " + trackerPackets[10]._source.layers["bt-tracker"]["bt-tracker.msg_type"] 
                        + "<br>&emsp;Request: " + trackerPackets[10]._source.layers["bt-tracker"]["bt-tracker.extension"]["bt-tracker.extension.urldata"]);
                    break;
                }
                if(direction == "backward"){ //contents of packets that are received from Tracker server
                    updateLog("Tracker request:" 
                        + "<br>&emsp;Packet type: " + trackerPackets[11]._source.layers["bt-tracker"]["bt-tracker.msg_type"] 
                        + "<br>&emsp;Response: " 
                        + "<br>&emsp;&emsp;Seeders: " + trackerPackets[11]._source.layers["bt-tracker"]["bt-tracker.seeders"] 
                        + "<br>&emsp;&emsp;Leechers: " + trackerPackets[11]._source.layers["bt-tracker"]["bt-tracker.leechers"]
                        + "<br>&emsp;Tracker list:" 
                        + "<br>&emsp;&emsp;Tracker1: " + trackerPackets[11]._source.layers["bt-tracker"]["bt-tracker.trackers"]["bt-tracker.tracker1"]["bt-tracker.tracker.ip"] + ":" + trackerPackets[11]._source.layers["bt-tracker"]["bt-tracker.trackers"]["bt-tracker.tracker1"]["bt-tracker.tracker.port"]
                        + "<br>&emsp;&emsp;Tracker2: " + trackerPackets[11]._source.layers["bt-tracker"]["bt-tracker.trackers"]["bt-tracker.tracker2"]["bt-tracker.tracker.ip"] + ":" + trackerPackets[11]._source.layers["bt-tracker"]["bt-tracker.trackers"]["bt-tracker.tracker2"]["bt-tracker.tracker.port"]
                        + "<br>&emsp;&emsp;Tracker3: " + trackerPackets[11]._source.layers["bt-tracker"]["bt-tracker.trackers"]["bt-tracker.tracker3"]["bt-tracker.tracker.ip"] + ":" + trackerPackets[11]._source.layers["bt-tracker"]["bt-tracker.trackers"]["bt-tracker.tracker3"]["bt-tracker.tracker.port"]);
                    break;
                }
            }
        }

        switch(direction){ //create edges based on direction
            case "forward":{
                for(var i = 0; i < 3; i++){
                    allEdges.push({
                        id: "STUN" + (i + 1),
                        from: i + 3,
                        to: target,
                        dashes: false,
                        physics: false,
                        color:{color: '#f2f2f2'},
                        width: 2,
                        arrows:{
                            to:{
                                enabled: true,
                                type: 'arrow',
                                scaleFactor: 1
                            }
                        },
                        endPointOffset:{to: 0}
        
                    });
                };
                break;
            };
            case "backward":{
                for(var i = 0; i < 3; i++){
                    allEdges.push({
                        id: "STUN" + (i + 1),
                        from: i + 3,
                        to: target,
                        dashes: false,
                        physics: false,
                        color:{color: '#f2f2f2'},
                        width: 2,
                        arrows:{
                            from:{
                                enabled: true,
                                type: 'arrow',
                                scaleFactor: 1
                            }
                        },
                        endPointOffset:{to: 0}
        
                    });
                };
                break;
            };
            default:
                //console.log("Error in connectToServer()");	
        };

        //console.log("All edges:", allEdges);
        network.body.data.edges.update(allEdges); //update all edges
        resolve(); //resolve promise when all edges are updated
    });
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------------------------Complete-animation---------------------------------------------------------------------//

function completeAnimation(){ //following function handles complete animation between all nodes, it combines server and peer animation
    return new Promise((resolve, reject) => {
        //console.log("completeAnimation() is called"); //debug
        ServerAnimation().then(() => { //start complete server animation
            return DelayFunction(500); //delay for animation
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';} //added additional check for stop button for better responsiveness //animation is stopped with thrown error
            return PeerDiscovery(); //start peer discovery animation
        })
        .then(() => {
            return DelayFunction(500); //delay for animation
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';}
            return PeerAnimation(); //start peer animation which includes downloading process
        })
        .then(() => {
            resolve(); //currently "completeAnimation()" doesn't resovle because of "PeerAnimation()" infinite loop
        })
        .catch((error) => {
            if(error == 'Animation stopped'){ 
                //console.log("Animation stopped"); //debug
                resolve(); //if animation is stopped, resolve the promise
            }
            else{
                console.log(error); //debug
                reject(error); //reject the promise with error
            }
        });
    })
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------------------------Node-interaction-----------------------------------------------------------------------//

function PeerDiscovery(){ //following function simulates the interaction between peer nodes
    return new Promise((resolve, reject) => {
        //console.log("PeerDiscovery() is called");
        DiscoveringSeeder("toSeed").then(() => { //simulate discovering seeder node
            return DelayFunction(800); //delay for animation
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';} //added additional check for stop button for better responsiveness //animation is stopped with thrown error
            return DiscoveringSeeder("toLeech"); //simulate discovering in reverse direction
        })
        .then(() => {
            return DelayFunction(800); //delay for animation
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';}
            return resetEdgeColorPeer(); //reset edges between peer nodes
        })
        .then(() => {
            resolve(); //resolve promise when discovery is completed
        })
        .catch((error) => {
            if(error == 'Animation stopped'){
                console.log("Animation stopped");
                resolve(); //if animation is stopped, resolve the promise
            }
            else{
                console.log(error); //debug
                reject(error);
            }
        });
    })
}

function DiscoveringSeeder(direction){ //following function simulates discovering peer node based on direction //direction: "toSeed" or "toLeech"
    return new Promise((resolve, reject) => {
        //console.log("DiscoveringSeeder() is called");
        var allEdges = network.body.data.edges.getIds(); //retrieve all edges from network
        var smoothType = "curvedCW"; //or "curvedCCW" -> "curvedCw" is considered as default value
        //console.log("All edges:", allEdges); //debug
        switch(direction){ //leech nodes discovering seeder node
            case "toSeed":{
                for(var i = 0; i < 2; i++){ //this for loop is stupid, but it works

                    if(i == 0){
                        smoothType = "curvedCCW";
                    }
                    else{
                        smoothType = "curvedCW";
                    }

                    allEdges.push({ //add from each leech node to seeder node
                        id: "toSeed" + (i + 1),
                        from: i + 1,
                        to: 0,
                        dashes: false,
                        physics: true,
                        color:{color: '#f2f2f2'},
                        width: 2,
                        arrows:{
                            to:{
                                enabled: true,
                                type: 'arrow',
                                scaleFactor: 1
                            }
                        },
                        endPointOffset:{to: 0},
                        smooth:{
                            enabled:true,
                            type: smoothType,
                            roundness: 0.10
                        }
    
                    });
                };
                break;
            }
            case "toLeech":{ //seeder node discovering leech nodes
                for(var i = 0; i < 2; i++){ //this for loop is stupid, but it works

                    if(i == 0){
                        smoothType = "curvedCCW";
                    }
                    else{
                        smoothType = "curvedCW";
                    }

                    allEdges.push({ //add edge from seeder node to each leech node
                        id: "toLeech" + (i + 1),
                        from: 0,
                        to: i + 1,
                        dashes: false,
                        physics: true,
                        color:{color: '#f2f2f2'},
                        width: 2,
                        arrows:{
                            to:{
                                enabled: true,
                                type: 'arrow',
                                scaleFactor: 1
                            }
                        },
                        endPointOffset:{to: 0},
                        smooth:{
                            enabled: true,
                            type: smoothType,
                            roundness: 0.10
                        }
    
                    });
                };
                break;
            }
            default:{
                console.log("Error in DiscoveringSeeder()");//debug
            };
        };
        network.body.data.edges.update(allEdges); //update all edges
        resolve(); //resolve promise when all edges are updated
    });
}

function Downloading(step){ //following function simulates the downloading process of a file between peer nodes //animation is based on two steps: step 0 and step 1
    return new Promise((resolve, reject) => {
        //console.log("Downloading() is called");
        var allEdges = network.body.data.edges.getIds(); //retrieve all edges from network
        var smoothType = "curvedCW"; //or "curvedCCW" -> "curvedCw" is considered as default value

        switch(step){ //add edges based on a step
            case 0:{ //first download step
                for(var i = 0; i < 2; i++){ //alternate between two types of curves for animation

                    if(i == 0){
                        smoothType = "curvedCCW"; //CCW - Counter ClockWise
                    }
                    else{
                        smoothType = "curvedCW"; //CW - ClockWise
                    }

                    allEdges.push({
                        id: "down" + (i + 1),
                        from: 0,
                        to: i + 1,
                        dashes: false,
                        physics: true,
                        color:{color: '#1fff00'}, //green color
                        width: 2,
                        arrows:{
                            to:{
                                enabled: true,
                                type: 'arrow',
                                scaleFactor: 1
                            }
                        },
                        endPointOffset:{to: 0},
                        smooth:{
                            enabled: true,
                            type: smoothType,
                            roundness: 0.10
                        }                       
                    });
                }
                allEdges.push({
                    id: "down3",
                    from: 1,
                    to: 2,
                    dashes: false,
                    physics: true,
                    color:{color: '#1fff00'}, //green color
                    width: 2,
                    arrows:{
                        to:{
                            enabled: true,
                            type: 'arrow',
                            scaleFactor: 1
                        }
                    },
                    endPointOffset:{to: 0},
                    smooth:{
                        enabled: true,
                        type: 'curvedCW',
                        roundness: 0.10
                    }
                });
                allEdges.push({
                    id: "down4",
                    from: 2,
                    to: 1,
                    dashes: false,
                    physics: true,
                    color:{color: '#002eff'}, //blue color
                    width: 2,
                    arrows:{
                        to:{
                            enabled: true,
                            type: 'arrow',
                            scaleFactor: 1
                        }
                    },
                    endPointOffset:{to: 0},
                    smooth:{
                        enabled: true,
                        type: 'curvedCW',
                        roundness: 0.10
                    }
                });
                break;
            }
            case 1:{ //second downloading step
                for(var i = 0; i < 2; i++){

                    if(i == 1){
                        smoothType = "curvedCCW";
                    }
                    else{
                        smoothType = "curvedCW";
                    }

                    allEdges.push({
                        id: "down" + (i + 1),
                        from: 0,
                        to: i + 1,
                        dashes: false,
                        physics: true,
                        color:{color: '#f2f2f2'}, //green color
                        width: 2,
                        arrows:{
                            from:{
                                enabled: true,
                                type: 'arrow',
                                scaleFactor: 1
                            }
                        },
                        endPointOffset:{to: 0},
                        smooth:{
                            enabled: true,
                            type: smoothType,
                            roundness: 0.10
                        }                       
                    });
                }
                allEdges.push({
                    id: "down3",
                    from: 1,
                    to: 2,
                    dashes: false,
                    physics: true,
                    color:{color: '#002eff'}, //blue color
                    width: 2,
                    arrows:{
                        to:{
                            enabled: true,
                            type: 'arrow',
                            scaleFactor: 1
                        }
                    },
                    endPointOffset:{to: 0},
                    smooth:{
                        enabled: true,
                        type: 'curvedCW',
                        roundness: 0.10
                    }
                });
                allEdges.push({
                    id: "down4",
                    from: 2,
                    to: 1,
                    dashes: false,
                    physics: true,
                    color:{color: '#1fff00'}, //green color
                    width: 2,
                    arrows:{
                        to:{
                            enabled: true,
                            type: 'arrow',
                            scaleFactor: 1
                        }
                    },
                    endPointOffset:{to: 0},
                    smooth:{
                        enabled: true,
                        type: 'curvedCW',
                        roundness: 0.10
                    }
                });
                break;
            }
            default:{
                console.log("Error in Downloading()"); //debug
            }
        }
        network.body.data.edges.update(allEdges); //update all edges
        resolve(); //resolve promise when all edges are updated
    });
}

function PeerAnimation(){ //following function controls the entire animation between peer nodes
    return new Promise((resolve, reject) => {
        //console.log("PeerAnimation() is called"); //debug

        startServerInterval(); //start server interval

        Downloading(0).then(() => { //begin with downloading step 0
            return DelayFunction(800); //delay for animation
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';} //added additional check for stop button for better responsiveness //animation is stopped with thrown error
            return resetEdgeColorPeer(); //reset edges between peer nodes
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';}
            return Downloading(1); //download step 1
        })
        .then(() => {
            return DelayFunction(800); //delay for animation
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';}
            return resetEdgeColorPeer(); //reset edges between peer nodes
        })
        .then(() => {
            if(stopBtn == true){throw 'Animation stopped';}
            PeerAnimation(); //repeat until animation is stopped with stop button
        })
        .catch((error) => {
            if(error == 'Animation stopped'){
                //console.log("Animation stopped"); //debug
                resolve(); //if animation is stopped, resolve the promise
            }
            else{
                console.log(error); //debug
                reject(error);
            }
        });
    });
}


//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------------------------Packet-reading-------------------------------------------------------------------------//

function fetchData(path) { //built in function to fetch JSON data from specified path
    return new Promise((resolve, reject) => {
        //console.log("fetchData() is called"); //debug
        fetch(path)
            .then(response => {
                if (!response.ok) { //check if response is ok
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json(); //return JSON data
            })
            .then(json => {
                resolve(json); //resolve the promise with JSON data
            })
            .catch(error => {
                console.error('Error fetching JSON data:', error); //debug
                reject(error); //reject the promise with error
            });
    });
}


function updateLog(text) { //following function updates the innerHTML of simulationLog
    var simulationLog = document.getElementById("simulationLog"); //get simulationLog element from HTML
    var newLog = document.createElement('p'); //create new paragraph element
    newLog.innerHTML = text; //set innerHTML of new paragraph element
    simulationLog.appendChild(newLog); //append new paragraph element so it doesn't overwrite other entries
    simulationLog.scrollTop = simulationLog.scrollHeight; //scroll to bottom
}
//------------------------------------------------------------------------------------------------------------------------------------------------------------//