var N = 10; //default value for node number
var SuperNodes; // variable was moved to global variable so it can be accessed from other functions 
var NormalNodes; // variable was moved to global variable so it can be accessed from other functions
var radius = 300; //the radius of the circle -> moved to global variable for value adjusting
var isGenerating = true; // extra flag to prevent event listener from interrupting the generation process
var completed = false; //flag for animation
var StopSimulation = false; //flag for stop button
var network = {}; //moved to global variable so that the function "Simulation" and other functions can access it
var SelectedNode = 1; //randomNode variable was renamed and moved to global variable to remove problem with promise chaining
var TargetNode = 1; //target node variable for Ring animation, default value is set to 1
var connectedSuperNode = 0; //moved to global variable so that the other functions can access it
var hop = 1; //gobal variable for number of hops for unstructured p2p network simulation
var slider, nodeNum, GenerateButton, GraphType, selectedGraph; //moved all variables from DOM event listener to global
var SimulateButton, StopButton, hopSlider, hopLabel, hopNum;


//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------Draw-Unstructured-P2P-Network---------------------------------------------------------------//

function DrawUnstructured(){ //main function for drawing unstructured p2p network

    var container = document.getElementById('container_simulation');
    //console.log(N);//debug
    var nodesMain = new vis.DataSet([]); //Create empty nodesMain
    var edgesMain = new vis.DataSet([]); //create empty edgesMain
    var data = {nodes: nodesMain, edges: edgesMain}; //combined variables
    var delay = 400; //delay for animation
    var i = 0, j = 0; //counters for nodes and edges


    var options = { //options object for network - part of the vis.js library
        height: '100%',
        width: '100%',
        nodes: {
            size: 20,
            borderWidth: 2,
            borderWidthSelected: 2,
            color: {
                background: '#f2f2f2',
                border: '#f2f2f2',
                highlight: {
                    background: '#a6c1ee',
                    border: '#1e90ff'
                }
            },
            shadow:{
                enabled: true,
                size: 6,
                color: '#d9d9d9'
            }
         },
         layout: {
            randomSeed: undefined,
            improvedLayout: true 
         },
         physics: {
            enabled: true,
            stabilization: false,
            barnesHut: {
                gravitationalConstant: -4000,
                springConstant: 0.001,
                springLength: 200,
                centralGravity: 0.2
              },
         },
         edges: {
            color: {
                color: '#f2f2f2',
                highlight: '#1e90ff',
            },
            width: 2
         }
    };


    function NodeGeneration(){ //returns promise for asynchronous node generation
        return new Promise((resolve, reject) => {
            function addNode() { //function for adding nodes
                if(i < N){
                    nodesMain.add({id: i, label: i + 1});
                    i++;
                    setTimeout(addNode, delay); //delay for animation like effect
                } else {
                    resolve(); //resolve promise when all nodes are added
                }
            };
            addNode();
        });
    };

    function EdgeGeneration(){
        NodeGeneration().then(() => { //first NodeGeneration() then EdgeGeneration()
            function addEdge() { //function for adding edges
                if(j < N){
                    var x1 = Math.floor(Math.random() * N); //connect to random x node;
                    var x2 = Math.floor(Math.random() * N); //connect to random x node;
                    var y = j; //temporary value
                    while(x1 == y || x2 == y || x1 == x2){ //check if nodes are already connected to avoid loops and self loops
                        x1 = Math.floor(Math.random() * N); 
                        x2 = Math.floor(Math.random() * N);
                    }
                    edgesMain.add({from: y, to: x1});
                    edgesMain.add({from: y, to: x2});
                    j++;
                    setTimeout(addEdge, delay);
                } 
                else {
                    completed = true;
                    disableUI(false); //re-enable UI
                    //console.log("Unstructured - completed:", completed); //debug

                    network.fit({ //fit the network to the container
                        animation: {
                            duration: 1000,
                            easingFunction: 'easeInOutQuad'
                        }
                    });
                }
            };
            addEdge(); //start adding edges
        });
    };

    EdgeGeneration();
    network = new vis.Network(container, data, options); //initialize network with container id, data and options
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------Event-Listeners-----------------------------------------------------------------------------//

document.addEventListener("DOMContentLoaded", function() { //wait for DOM to be loaded before running the code

    slider = document.getElementById("numSlider"); //get references to multiple HTML elements
    nodeNum = document.getElementById("numNode");
    GenerateButton = document.getElementById("GenerateButton");
    GraphType = document.getElementById("GraphType");
    selectedGraph = "Unstructured"; //default graph type
    SimulateButton = document.getElementById("SimulateButton");
    StopButton = document.getElementById("StopButton");
    hopSlider = document.getElementById("hopSlider");
    hopLabel = document.getElementById("hopLabel");
    hopNum = document.getElementById("hopNum");

    disableUI(true).then(() => DrawUnstructured()); //default function for first load of the page also disables UI
    hopLabel.style.display = "block"; //show hop UI elements by default
    hopSlider.style.display = "inline-block";
    hopNum.style.display = "inline-block";

    slider.addEventListener("input", function() { //event listener for the node number slider
        N = parseInt(this.value); //update the number of nodes
        nodeNum.textContent = N; //display the number of nodes in the UI
        radius = N * 40; //adjusted radius to fit the number of nodes  
    });

    hopSlider.addEventListener("input", function() {//event listener for the hop slider
        hop = parseInt(this.value); //update the number of hops
        hopNum.textContent = hop; //display the number of hops in the UI
    })

    GraphType.addEventListener("change", function() { //event listener for the graph type drop down menu
        selectedGraph = GraphType.value; //get the selected graph type

        if(selectedGraph == "Hybrid"){ //adjust the slider min value based on the selected graph type
            slider.min = 10;
            if(nodeNum.textContent == 5){
                nodeNum.textContent = 10;
            }
        }
        else{
            slider.min = 5;
        }

        switch(selectedGraph){ //show/hide hop UI elements based on the selected graph type
            case "Unstructured":
                hopLabel.style.display = "block";
                hopSlider.style.display = "inline-block";
                hopNum.style.display = "inline-block";
                break;
            case "Structured":
                hopLabel.style.display = "none";
                hopSlider.style.display = "none";
                hopNum.style.display = "none";
                break;
            case "Hybrid":
                hopLabel.style.display = "none";
                hopSlider.style.display = "none";
                hopNum.style.display = "none";
                break
            default:
                console.log("Error"); //debug       
        }

        //console.log("Graph type listener:",selectedGraph); //debug
    });

    GenerateButton.addEventListener("click",function() { //event listener for the generate button
        //console.log("Button is clicked");
        disableUI(true); //disable UI while animation is running
            switch(selectedGraph){
                case "Unstructured":
                    completed = false;
                    //console.log("Unstructured - completed:", completed); //debug
                    resetEdgeColors(); //reset edge colors
                    resetNodeColors(); //reset node colors
                    DrawUnstructured(); //draw unstructured p2p network
                    break;
                case "Structured":
                    completed = false;
                    //console.log("Structured - completed:", completed); //debug
                    resetEdgeColors(); //reset edge colors
                    resetNodeColors(); //reset node colors
                    DrawStructured(); //draw structured p2p network
                    break;
                case "Hybrid":
                    completed = false;
                    //console.log("Hybrid - completed:", completed); //debug
                    resetEdgeColors(); //reset edge colors
                    resetNodeColors(); //reset node colors
                    DrawHybrid(); //draw hybrid p2p network
                    break;    
                default:
                    console.log("Error"); //debug       
            };

    });

    SimulateButton.addEventListener("click", function() { //event listener for the simulate button
        StopSimulation = false; //reset stop stimulation flag
        if(completed == true){ //only simulate if the network is generated
            //console.log("Simulate button is clicked"); //debug
            disableUI(true); //disable UI while animation is running
            StopButton.style.display = "block"; //show stop button
            switch(selectedGraph){
                case "Unstructured":
                    loopFloodAnimation(); //run animation for unstructured P2P network
                    break;
                case "Structured":
                    loopRingAnimation(); //run animation for structured P2P network
                    break;
                case "Hybrid":
                    loopHybridAnimation(); //run animation for hybrid P2P network
                    break;
                default:
                    console.log("Error"); //debug    
            };
        };
    });

    StopButton.addEventListener("click", function() { //event listener for the stop button
        //console.log("Stop button is clicked"); //debug
        StopButton.style.display = "none"; //hide stop button
        StopSimulation = true; //set flag to stop the simulation - looping function
        disableUI(false); //re-enable UI
    });

});

function disableUI(disable){ //following function is used to disable UI elements while animation is running
    return new Promise(resolve => {
        //console.log("Disable UI:", disable); //debug
        slider.disabled = disable;
        hopSlider.disabled = disable;
        GenerateButton.disabled = disable;
        SimulateButton.disabled = disable;
        GraphType.disabled = disable;
        resolve();
    })
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//-----------------------------------------------------------Draw-Structured-P2P-Network---------------------------------------------------------------------//

function DrawStructured(){ //main function for drawing structured p2p network

    var container = document.getElementById('container_simulation');
    //console.log("Number of nodes:",N); //debug
    //console.log("Radius:", radius); //debug
    var nodesMain = new vis.DataSet([]); //create empty nodesMain
    var edgesMain = new vis.DataSet([]); //create empty edgesMain
    var data = {nodes: nodesMain, edges: edgesMain}; //combined nodes and edges into data object
    var delay = 400; //delay for animation
    var i = 0; j = 0; //counters for nodes and edges
    var increment = 2 * Math.PI / N; //angle increment between nodes for circular layout
    var existingEdges = new Set(); // set to track existing edges for preventing duplicates


    var options = { //options object for network - part of the vis.js library
        height: '100%',
        width: '100%',
        nodes: {
            size: 20,
            borderWidth: 2,
            borderWidthSelected: 2,
            color: {
                background: '#f2f2f2',
                border: '#f2f2f2',
                highlight: {
                    background: '#a6c1ee',
                    border: '#1e90ff'
                }
            },
            shadow:{
                enabled: true,
                size: 6,
                color: '#d9d9d9'
            }
         },
         layout: {
            improvedLayout: false
         },
         physics: { //physics are enabled for edges
            enabled: true,
            stabilization: {
                enabled: false
            }
         },
        edges: {
            color: {
                color: '#f2f2f2',
                highlight: '#1e90ff',
            },
            width: 2,
            length: radius - 300,
            smooth: {
                enabled: true,
                type: 'dynamic'
            }
        } 
    };


    function NodeGeneration(){ //function for generating nodes in circular layout
        return new Promise((resolve, reject) => { //using promises for asynchronous functions
            function addNode() {
                if(i < N){
                    var angle = i * increment; //angle of node
                    var x = radius * Math.cos(angle); //x coordinate
                    var y = radius * Math.sin(angle); //y coordinate
                    nodesMain.add({id: i, label: i, x: x, y: y, physics: false}); //added x and y coordinates
                    i++;
                    setTimeout(addNode, delay); //delay for animation
                } else {
                    resolve(); //resolve promise when done
                }
            };
            addNode();
        });
    };

    function EdgeGeneration(){ //edge generation using formula i = (j + 2^k) mod N - based on a chord algorithm
        NodeGeneration().then(() => { //wait for node generation to finish
            function addEdge() {
                if(j < N){
                    //console.log("j:", j); // debug
                    var k = Math.floor(Math.log2(N)); //maximum value of k
                    var NodeRef;
    
                    for(var l = 0; l <= k; l++){
                        NodeRef = ((j + Math.pow(2, l)) % N); //calculate node references for egde generation
                        if(NodeRef != j){ //avoid self loops and duplicates
                            var edgeString = `${j}-${NodeRef}`;
                            var reverseEdgeString = `${NodeRef}-${j}`;
    
                            if (!existingEdges.has(edgeString) && !existingEdges.has(reverseEdgeString)) { //check if edge already exists
                                edgesMain.add({ from: j, to: NodeRef });
                                existingEdges.add(edgeString);
                                existingEdges.add(reverseEdgeString);
                            }
                        }
                    }
                    j++;
                    setTimeout(addEdge, delay); //delay for animation
                }
                else{
                    completed = true;
                    disableUI(false); //re-enable UI
                    //console.log("Structured - completed:", completed);

                    network.fit({ //fit the network to the container
                        animation: {
                            duration: 1000,
                            easingFunction: 'easeInOutQuad'
                        }
                    });
                }
            };
            addEdge(); //start edge generation
        });
    };

    EdgeGeneration();
    network = new vis.Network(container, data, options); //initialize network with container id, data and options

    network.on("dragEnd", function (event) { //event listener for node dragging to fix circular layout
        var nodeId = event.nodes[0]; 
        var node = nodesMain.get(nodeId); 
        
        if (node) {
            var angle = (Math.atan2(node.y, node.x) + 2 * Math.PI) % (2 * Math.PI); //maths :)
            var newX = radius * Math.cos(angle); //fiexed x and y coordinates 
            var newY = radius * Math.sin(angle); 
            node.x = newX; 
            node.y = newY; 
            nodesMain.update(node); //update node position
        }
        //console.log("Fixed node: " + nodeId); //debug
    });
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//----------------------------------------------------------Draw-Hybrid-P2P-Network--------------------------------------------------------------------------//

function DrawHybrid(){ //main function for drawing hybrid p2p network

    var container = document.getElementById('container_simulation');
    //console.log("Number of nodes:",N);
    //console.log("Radius:", radius);
    var nodesMain = new vis.DataSet([]); //Create empty nodesMain
    var edgesMain = new vis.DataSet([]); //create empty edgesMain
    var data = {nodes: nodesMain, edges: edgesMain}; //object with nodes and edges
    var delay = 500; //delay for animation
    var i = 0; j = 0; //counters for nodes and edges


    var options = { //options object for network - part of the vis.js library
        height: '100%',
        width: '100%',
        nodes: {
            size: 20,
            borderWidth: 2,
            borderWidthSelected: 2,
            color: {
                background: '#f2f2f2',
                border: '#f2f2f2',
                highlight: {
                    background: '#a6c1ee',
                    border: '#1e90ff'
                } 
            },
            shadow:{
                enabled: true,
                size: 6,
                color: '#d9d9d9'
            }
         },
         layout: {
            improvedLayout: false 
         },
         physics: { //physics had to be adjusted for the animation
            enabled: true,
            stabilization: false
         },
         edges: {
            color: {
                color: '#f2f2f2',
                highlight: '#1e90ff',
            },
            width: 2
         }
    };

    //define number of super and normal nodes
    SuperNodes = Math.floor(Math.random() * N/2); // random number of super nodes between 1 and N/2
    NormalNodes = N - SuperNodes; //number of normal nodes based on number of super nodes

    while(SuperNodes < 3){ //minimum 3 super nodes to keep the newtwork graph consistent
        SuperNodes = Math.floor(Math.random() * N/2);
        NormalNodes = N - SuperNodes;
    }

    //console.log("Number of super nodes:", SuperNodes); //debug
    //console.log("Number of normal nodes:", NormalNodes); //debug

    var increment = (2 * Math.PI) / SuperNodes; //angle increment between super nodes

    function NodeGeneration(){ //function for adding nodes
        return new Promise((resolve, reject) => { //based on promise statement for asynchronous code
            function addNode() {
                if(i < SuperNodes){ //adding super nodes
                    var angle = i * increment; //angle of node
                    var x = radius * Math.cos(angle); //x coordinate
                    var y = radius * Math.sin(angle); //y coordinate
                    nodesMain.add({id: i, label: i + 1, x: x, y: y, physics: false, shape: 'square'}); //added x and y coordinates //super nodes are addionally drawn as squares to separate them from normal nodes
                    //console.log("id 1 value:", i); //debug
                    i++;
                    setTimeout(addNode, delay); //delay for animation
                }
                else if(i >= SuperNodes && i < N){ //adding normal nodes
                    nodesMain.add({id: i, label: i});
                    //console.log("id 2 value:", i); //debug
                    i++;
                    setTimeout(addNode, delay); //delay for animation
                }
                else{
                    resolve(); //resolve promise when all nodes are added
                }
            };
            addNode();
        });
    };

    function EdgeGeneration(){ //function for adding edges
        NodeGeneration().then(() => { //wait for node generation to finish 
            function addEdge() {
                if(j < SuperNodes - 1){ //connect super nodes
                    edgesMain.add({from: j, to: j + 1}); //super node connections
                    //console.log("from value:", j, "to value:", j + 1); //debug
                    j++;
                    setTimeout(addEdge, delay);
                }
                else if (j == SuperNodes - 1){ //connect final super node to the first one
                    edgesMain.add({from: j, to: 0}); //final super node connection
                    setTimeout(addEdge, delay);
                    //console.log("from value:", j - 1, "to value:", 0); //debug
                    j++;
                }
                else if(j >= SuperNodes && j <= N){ //connect normal nodes to random super nodes
                    var x = Math.floor(Math.random() * SuperNodes); //connect node j to random super node x
                    edgesMain.add({from: j, to: x});
                    //console.log("from value:", j, "to value:", j); //debug
                    setTimeout(addEdge, delay);
                    j++;
                }
                else{
                    completed = true;
                    disableUI(false); //re-enable UI
                    //console.log("Hybrid - completed:", completed);

                    network.fit({ //fit the network to the container
                        animation: {
                            duration: 1000,
                            easingFunction: 'easeInOutQuad'
                        }
                    });
                }
            };
            addEdge();
        });
    };

    EdgeGeneration();
    network = new vis.Network(container, data, options); //initialize network  
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//------------------------------------------------------------Unstructured-P2P-network-simulation------------------------------------------------------------//
function FloodAnimation() { //based on modified BFS algorithm
    return new Promise((resolve, reject) => {
        //console.log("FloodAnimation() is called"); //debug
        //console.log("Number of nodes:", N);
        //console.log("Hop number:", hop);
        var delay = 800;
        var StartNodeColor = {background: '#FF4C4C', border: '#B22222'}; //color for start node
        var EndNodeColor = {background: '#32CD32', border: '#228B22'}; //color for destination node
        var queueDone = []; //queue for nodes that have been visited -- Previous node
        var queueTemp = []; //queue for nodes that are currently selected -- Current node
        var queueVisit = []; //queue for nodes that are next in the line to be visited -- Next node or node that is connect to current node and haven't been visited yet
        var k = 1; //counter for hops
    
        //resetNodeColors(); //reset node colors
        //resetEdgeColors(); //reset edge colors

        SelectedNode = Math.floor(Math.random() * (N - 1)); //select random node to start from
        TargetNode = Math.floor(Math.random() * (N - 1)); //select random target node
        
        while (TargetNode == SelectedNode) { //update target node if it is the same as the selected node
            TargetNode = Math.floor(Math.random() * (N - 1));
        }
        
        console.log("Selected node:", SelectedNode); //debug
        console.log("Target node:", TargetNode); //debug
        
        network.body.data.nodes.update({id: SelectedNode, color: StartNodeColor}); //Mark start node
        network.body.data.nodes.update({id: TargetNode, color: EndNodeColor}); //Mark end node

    
        queueTemp.push(SelectedNode); //initialize queue with start node

        if(StopSimulation == true){ //if stop button is pressed, reset colors of all nodes and edges
            resetEdgeColors().then(() => resetNodeColors());
            resolve();
            return;
        }

        async function animate() { //function for animating flooding
            console.log("value of k:", k); //debug

            if(StopSimulation == true){ //if stop button is pressed, reset colors of all nodes and edges
                await resetEdgeColors();
                await resetNodeColors();
                resolve();
                return;
            }

            if (k > hop) { //if the number of hops has reached the hop limit stop the simulation
                await new Promise(resolve => setTimeout(resolve, delay));
                console.log("Resolve was called in if");
                resolve();
                return;  
            }

            queueVisit = queueFiltering(connectedNodes(queueTemp), queueDone); //filter out nodes that are already visited 
            queueDone = []; //reset queueDone for next iteration
            queueTemp = []; //reset queueTemp for next iteration
                
            if(QueryForwarding(queueVisit) == true){
                await new Promise(resolve => setTimeout(resolve, delay));
                //console.log("Resolve was called in if 2");
                resolve();
                return;
            } ;
            
            for(var h = 0; h < queueVisit.length; h++){ //add nodes in queueVisit to queueDone
                if(StopSimulation == true){
                    await resetEdgeColors();
                    await resetNodeColors();
                    resolve();
                    return;
                }
                queueDone.push(queueVisit[h].node);
            }
        
            for(var i = 0; i < queueVisit.length; i++){ //add connections of nodes in queueVisit to queueTemp
                for(var j = 0; j < queueVisit[i].connections.length; j++){
                    if(StopSimulation == true){
                        await resetEdgeColors();
                        await resetNodeColors();
                        resolve();
                        return;
                    }
                    queueTemp.push(queueVisit[i].connections[j]);
                }
            }
            queueTemp = queueTemp.filter((num, index) => queueTemp.indexOf(num) === index); //filter out duplicates
            queueVisit = []; //reset queueVisit for next iteration
                
            //console.log("Queue done:", queueDone, "Queue visit:", queueVisit, "Queue temp:", queueTemp); //debug
            k++;
            setTimeout(animate, delay); //call animate function after delay // !! don't call function with () !!   
        }
        setTimeout(() => {
            animate();
        }, delay);

    });

}

function resetNodeColors(){ //following function resets colors of all nodes to default color
    return new Promise((resolve, reject) => { 
        //console.log("resetNodeColors() is called"); //debug
        var allNodes = network.body.data.nodes.getIds(); //retrieve all nodes
        //console.log("All nodes:", allNodes); //debug
        var resetColor = {background: '#f2f2f2', border: '#f2f2f2'}; //default color
        var nodesToUpdate = []; //array of nodes to be updated
    
        allNodes.forEach(function(nodeID){
            nodesToUpdate.push({id: nodeID, color: resetColor});
        });
        network.body.data.nodes.update(nodesToUpdate); //update nodes
        resolve();
    });
}

function QueryForwarding(queueVisit){ //following function handles the visual part of flooding animation
    //console.log("QueryForwarding() is called"); //debug
    //resetEdgeColors();
    var EdgeColor = {color: '#1848cc'}; //color for active edge
    var edgesToUpdate = [];
    var edgesToUpdateFinal = [];
    var edges = network.body.data.edges.getIds(); //retrieve all edges
    var targetEdgeId;

    //console.log("Queue visit:", queueVisit); //debug

    for(var i = 0; i < queueVisit.length; i++){ 
        for(var j = 0; j < queueVisit[i].connections.length; j++){ //loop through connections of nodes in queueVisit
            for(var k = 0; k < edges.length; k++){ //loop through edges
                if(StopSimulation == true){ //added stop button check for better responsiveness
                    resetEdgeColors().then(() => resetNodeColors());
                    return false;
                }
                var edge = network.body.data.edges.get(edges[k]); //get edge object
                if((edge.from == queueVisit[i].node && edge.to == queueVisit[i].connections[j]) || (edge.from == queueVisit[i].connections[j] && edge.to == queueVisit[i].node)){
                    if(queueVisit[i].connections[j] == TargetNode){ //if target node was found
                        targetEdgeId = edges[k];
                        edgesToUpdateFinal.push({id: targetEdgeId, color: EdgeColor}); //update edge color
                        //console.log("Destination node was found");
                        //console.log("Edge ID between nodes:", queueVisit[i].node, "and", queueVisit[i].connections[j], "is:", targetEdgeId); //debug
                        break;
                    }
                    targetEdgeId = edges[k];
                    edgesToUpdate.push({id: targetEdgeId, color: EdgeColor}); //update edge color
                    //console.log("Edge ID between nodes:", queueVisit[i].node, "and", queueVisit[i].connections[j], "is:", targetEdgeId); //debug
                    break;
                }
            }
        }
    }
    //console.log("Edges to update:", edgesToUpdate); //debug


    if(edgesToUpdateFinal.length > 0){ // update edge color 
        network.body.data.edges.update(edgesToUpdateFinal);
        //console.log("Target node was found via following nodes:", edgesToUpdateFinal); //debug
        return true;
    }
    else{
        network.body.data.edges.update(edgesToUpdate);
        return false;
    }
}

function connectedNodes(queueTemp){ //following function returns connected nodes to a given set of nodes
    var queueVisit = [];
    var currentNode = 0;
    var connectedNodes = [];
    //console.log("connectedNodes() is called"); //debug
    //console.log("Queue temp on the input:", queueTemp); //debug

    for(var i = 0; i < queueTemp.length; i++){ //loop through queueTemp, for each node in queueTemp get connected nodes
        if(StopSimulation == true){
            resetNodeColors().then(() => resetEdgeColors());
            return queueVisit;
        }
        currentNode = queueTemp[i];
        connectedNodes = network.getConnectedNodes(currentNode);
        queueVisit.push({node: currentNode, connections: connectedNodes});
    }

    //console.log("Queue visit on the output:", queueVisit); //debug

    return queueVisit; //return an array of nodes with their connected nodes

}

function queueFiltering(queueVisit, queueDone){ //following function filters out nodes that have already been visited
    console.log("queueFiltering() is called"); //debug
    //console.log("Queue to filter:", queueVisit); //debug
    //console.log("Node to filter out:", queueDone); //debug

    for(var i = 0; i < queueDone.length; i++){
        if(StopSimulation == true){ //added stop button check for better responsiveness
            resetNodeColors().then(() => resetEdgeColors());
            return queueVisit;
        }
        for(var j = 0; j < queueVisit.length; j++){ //loop through queueVisit and remove already visited nodes 
            for(var k = 0; k < queueVisit[j].connections.length; k++){
                if(queueVisit[j].connections[k] == queueDone[i]){
                    queueVisit[j].connections.splice(k,1);
                    k--;
                }
            }
        }
    }

    //console.log("Filtered queue:", queueVisit); //debug

    return queueVisit;

}


function loopFloodAnimation(){ //following function loops the animation until stop button is pressed
    return new Promise((resolve, reject) => {
        console.log("loopFloodAnimation() is called"); //debug
        resetEdgeColors().then(() => { //reset edge colors
            resetNodeColors().then(() => { //reset node colors
                if(StopSimulation == false){ //if stop button is not pressed run FloodAnimation then call loopFloodAnimation again
                    FloodAnimation()
                        .then(() => loopFloodAnimation())
                        .catch(error => reject(error));
                }
                else{
                    resetNodeColors().then(() => {
                        resetEdgeColors().then(() => resolve());
                    });
                }
            })
        })
    })
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//-----------------------------------------------------------------Hybrid-P2P-network-simulation-------------------------------------------------------------//

async function HybridAnimation() { //main function for hybrid P2P network simulation //using async/await syntax for asynchronous code
    //console.log("HybridAnimation() is called"); //debug

    try {
        await resetEdgeColors(); //reset edge colors
        if(StopSimulation == true){ //added stop button check for better responsiveness
            await resetNodeColors();
            await resetEdgeColors();
            return;
        }
        await resetNodeColors(); //reset node colors
        if(StopSimulation == true){
            await resetNodeColors();
            await resetEdgeColors();
            return;
        }
        await randomNodeSelect(); //select random start node and target node
        if(StopSimulation == true){
            await resetNodeColors();
            await resetEdgeColors();
            return;
        }
        const path = await discoverTargetNode(); //discover the shortest path from start node to target node
        if(StopSimulation == true){
            await resetNodeColors();
            await resetEdgeColors();
            return;
        }
        await drawPath(path); //animate the drawing of the shortest path
        if(StopSimulation == true){
            await resetNodeColors();
            await resetEdgeColors();
            return;
        }
        //console.log("HybridAnimation() is done"); //debug
    } catch (error) {
        console.error('Error in HybridAnimation:', error);
    }
}

async function loopHybridAnimation() { //following function loops the HybridAnimation() until stop button is pressed
    //console.log("loopHybridAnimation() is called"); //debug

    try {
        while (StopSimulation == false) { // create an infinite loop while stop button is not pressed
            await HybridAnimation(); // wait for HybridAnimation to complete
            if(StopSimulation == true){
                await resetNodeColors();
                await resetEdgeColors();
                return;
            }
            await DelayFunction(800); // wait for the specified delay time before the next iteration
            if(StopSimulation == true){
                await resetNodeColors();
                await resetEdgeColors();
                return;
            }
        }
    } catch (error) {
        console.error('Error in loopHybridAnimation:', error);
    }
}


function DelayFunction(ms) { //utility function for delay
    return new Promise(resolve => setTimeout(resolve, ms));
}

function randomNodeSelect() { //following function selects random start and target nodes //start node is chosen randomly from normal nodes meanwhile target node is chosen randomly from all nodes
    return new Promise((resolve, reject) => {
        console.log("randomNodeSelect() is called"); //debug
        var nodeColorStart = { background: '#FF4C4C', border: '#B22222'}; //start node highlight color
        var nodeColorStop = { background: '#32CD32', border: '#228B22'}; //destination node highlight color
        var nodesToUpdate = [];

        if(StopSimulation == true){ //added stop button check for better responsiveness
            resolve();
            return;
        }

        SelectedNode = (Math.floor(Math.random() * NormalNodes)) + SuperNodes; //select random normal node for starting node - offset by number of super nodes
        while (SelectedNode < SuperNodes) {
            SelectedNode = (Math.floor(Math.random() * NormalNodes)) + SuperNodes; //number must be greater than number of super nodes to avoid ID problems
        }

        TargetNode = Math.floor(Math.random() * (N - 1)); //select random target node

        while (TargetNode == SelectedNode) {
            TargetNode = Math.floor(Math.random() * (N - 1)); //update target node if it is same as selected start node
        }


        nodesToUpdate.push({ id: TargetNode, color: nodeColorStop }); //update graph with new colors
        nodesToUpdate.push({ id: SelectedNode, color: nodeColorStart });
        network.body.data.nodes.update(nodesToUpdate);
        //console.log("Random normal node:", SelectedNode); //debug 
        resolve();
    });
}

function discoverTargetNode() { //this function discovers the shortest path from selected node to target node in both clockwise (CW) and counter-clockwise (CCW) directions
    return new Promise((resolve, reject) => {
        //console.log("---------------------------------------------------------");//for better readability
        //console.log("discoverTargetNode() is called");//debug
        
        
        var firstSuperNode = network.getConnectedNodes(SelectedNode)[0]; //get first super node from start node
        var allSuperNodes = []; // array with all super nodes
        var allNodes = [];
        var pathCW = []; // path from selected node to target node (clockwise)
        var pathCCW = []; // path from selected node to target node (counter-clockwise)
        var path = []; // final path from selected node to target node

        //console.log("First super node:", firstSuperNode); //debug

        for (var i = 0; i < SuperNodes; i++) { //populate the array with all super nodes
            allSuperNodes.push(i);
        }
        //console.log("all super nodes:", allSuperNodes); //debug

        for (var i = 0; i < allSuperNodes.length; i++) { //for each super node get all connected nodes except super nodes
            allNodes[i] = [];
            var tempNodes = network.getConnectedNodes(allSuperNodes[i]);
            tempNodes = tempNodes.filter(node => node >= SuperNodes); // filter out super nodes
            allNodes[i] = tempNodes;
        }

        //console.log("all nodes:", allNodes); //debug

        function CWPath(startSuperNode, targetNode) { //following function returns the shortest path from start node to target node in clockwise direction
            let path = [];
            let startIndex = allSuperNodes.indexOf(startSuperNode); //new thing that i've added: "indexOf" returns the index of specified element in the array

            for (let i = 0; i < allSuperNodes.length; i++) {
                let nodeIndex = (startIndex + i) % allSuperNodes.length;
                let currentSuperNode = allSuperNodes[nodeIndex];
                path.push(currentSuperNode);
                if(StopSimulation == true){
                    resetEdgeColors().then(() => {
                        resetNodeColors();
                    }).then(() => {
                        resolve();
                    })
                    return;
                }
                if (currentSuperNode === targetNode || allNodes[nodeIndex].includes(targetNode)) {
                    path.push(targetNode);
                    return path; 
                }
            }
            return path;
        }

        function CCWPath(startSuperNode, targetNode) { //following function returns the shortest path from start node to target node in counter-clockwise direction
            let path = [];
            let startIndex = allSuperNodes.indexOf(startSuperNode);

            for (let i = 0; i < allSuperNodes.length; i++) {
                let nodeIndex = (startIndex - i + allSuperNodes.length) % allSuperNodes.length;
                let currentSuperNode = allSuperNodes[nodeIndex];
                path.push(currentSuperNode);
                if(StopSimulation == true){
                    resetEdgeColors().then(() => {
                        resetNodeColors();
                    }).then(() => {
                        resolve();
                    })
                    return;
                }
                if (currentSuperNode === targetNode || allNodes[nodeIndex].includes(targetNode)) {
                    path.push(targetNode);
                    return path; 
                }
            }
            return path;
        }

        function removeDuplicates(array) { //function for filtering out duplicate entries
            return array.filter((item, index) => array.indexOf(item) === index); //.filter() is built in function that is used to remove duplicate entries from an array
        }

        pathCW = CWPath(firstSuperNode, TargetNode); //get CW path
        if(StopSimulation == true){ //added stop button check for better responsiveness
            resetEdgeColors().then(() => {
                resetNodeColors();
            }).then(() => {
                resolve();
            })
            return;
        }
        pathCCW = CCWPath(firstSuperNode, TargetNode); //get CCW path
        if(StopSimulation == true){
            resetEdgeColors().then(() => {
                resetNodeColors();
            }).then(() => {
                resolve();
            })
            return;
        }
        //console.log("Clockwise Path:", pathCW);
        //console.log("Counter-Clockwise Path:", pathCCW);

        if(pathCW.length < pathCCW.length) { //compare paths
            pathCW = removeDuplicates(pathCW);
            path = pathCW;
            path.unshift(SelectedNode); //add star node to the beginning of the path // .unshift() adds an element to the beginning of an array
        }
        else {
            pathCCW = removeDuplicates(pathCCW);
            path = pathCCW;
            path.unshift(SelectedNode);
        }

        //console.log("Shortest Path:", path);

        resolve(path);
    });
}

function drawPath(path) { //following function animates the drawing of the shortest path by highlighting the edges
    //console.log("drawPath() is called");

    return new Promise((resolve, reject) => {
        var allEdges = network.body.data.edges.get(); //get all edges in the network
        var EdgeColor = { color: '#1848cc'}; //edge color for highlighting
        var timeoutdelay = 800; //delay for animation

        function updateEdge(edgeId) { //function to update edge color
            return new Promise((resolve) => {
                network.body.data.edges.update({ id: edgeId, color: EdgeColor });
                resolve();
            });
        }

        function delay(ms) { //utility function for delay
            return new Promise(resolve => setTimeout(resolve, ms));
        }

        function animateEdges(edges) { //function that animates edge updating
            let promiseChain = Promise.resolve(); //initialize promise chain with a resolved promise

            edges.forEach((edgeId) => { //loop through all edges //.forEach() is a built in function that works similar to a for loop
                promiseChain = promiseChain //for each edge extend the promise chain
                    .then(() => {
                        if(StopSimulation == true){ //if stop button was pressed, stop the animation with error
                            throw new Error('Animation stopped');
                        }
                        return updateEdge(edgeId) //update edge color
                    })
                    .then(() => delay(timeoutdelay)); //delay for animation
            });

            return promiseChain; //return the promise chain after all edges have been updated
        }

        var edgesToUpdate = [];

        for (var i = 0; i < path.length - 1; i++) { //find edges that need to be updated based on the path
            var node1 = path[i];
            var node2 = path[i + 1];
            allEdges.forEach(edge => {
                if ((edge.from == node1 && edge.to == node2) || (edge.from == node2 && edge.to == node1)) {
                    edgesToUpdate.push(edge.id);
                }
            });
        }

        delay(timeoutdelay) //start edge animation with a delay
            .then(() => animateEdges(edgesToUpdate)) //animate edges
            .then(() => {
                //console.log('All edges updated'); //debug
                resolve();
            })
            .catch((error) => {
                if(error.message === 'Animation stopped') { //if stop button was pressed stop the animation
                    //console.log('Simulation stopped'); //debug
                    resetEdgeColors().then(() => {
                        resetNodeColors().then(() => resolve());
                    });
                }
                else {
                    console.error("Error during the animation: ",error);
                    reject(error);
                }

            });
    });
}



//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------------------Structured-P2P-network-simulation------------------------------------------------------------//

function RingAnimation() { //main function for animating structured p2p network
    return new Promise((resolve, reject) => {
        //console.log("Ring animation is called"); //debug
        var delay = 800;
        var StartNodeColor = {background: '#FF4C4C', border: '#B22222'}; //highlight color for start node
        var EndNodeColor = {background: '#32CD32', border: '#228B22'}; //highlight color for destination node
        var EdgeColor = {color: '#1848cc'}; //highlight color for active edges
        var nodesToUpdate = []; //array of nodes to be updated
        var queueCW = []; //queue for nodes clockwise direction
        var queueCCW = []; //queue for nodes counter-clockwise direction
    
        //resetNodeColors();
        //resetEdgeColors();
    
        //console.log("Number of nodes present in the ring:", N); //debug
    
        SelectedNode = Math.floor(Math.random() * (N - 1)); //select random node to start from
        TargetNode = Math.floor(Math.random() * (N - 1)); //select random target node
    
        while(TargetNode == SelectedNode){
            TargetNode = Math.floor(Math.random() * (N - 1)); //update target node if it is same as selected node
        }
        //console.log("Selected node:", SelectedNode); //debug
        //console.log("Target node:", TargetNode); //debug
        network.body.data.nodes.update({ id: SelectedNode, color: StartNodeColor }); //update start node
        network.body.data.nodes.update({ id: TargetNode, color: EndNodeColor }); //update end node

        function animate() { //following function animates pathfinding
            if(StopSimulation == true){ //added to stop the animation when stop button is pressed
                resetEdgeColors().then(() => {
                    resetNodeColors().then(() => resolve());
                })
                return;
            }
            if(nodesToUpdate[nodesToUpdate.length - 1] == TargetNode){ //check if target node is reached
                resolve();
                return;
            }
            nodesToUpdate.push(SelectedNode);
    
            queueCW = RefrencedNodesCW(SelectedNode);
            queueCCW = RefrencedNodesCCW(SelectedNode);
            //console.log("Node:", SelectedNode, "is connected to nodes:", queueCW, "clockwise"); //debug
            //console.log("Node:", SelectedNode, "is connected to nodes:", queueCCW, "counterclockwise"); //debug
        
            var distanceObj =  NodeDistance(queueCW, queueCCW, TargetNode); //get distance between selected node and target node
            //console.log("Object output test:", distanceObj); //debug
            
            if(distanceObj.CW.distance < distanceObj.CCW.distance){ //chose the shortest path //beautiful else if chain :)
                SelectedNode = distanceObj.CW.node;
            }
            else if(distanceObj.CW.distance > distanceObj.CCW.distance){
                SelectedNode = distanceObj.CCW.node;
            }
            else if(distanceObj.CW.distance == distanceObj.CCW.distance){
                SelectedNode = distanceObj.CW.node; //if distances are equal, the result doesnt matter in that case pick CW
            }
            else{
                console.log("Error"); //debug
            }
    
    
            if(nodesToUpdate.length > 1){ //update graph edges with new colors
                //console.log("Edge from:", nodesToUpdate[nodesToUpdate.length - 1], "to:", nodesToUpdate[nodesToUpdate.length - 2]); //debug
    
                var startNode = nodesToUpdate[nodesToUpdate.length - 1];
                var endNode = nodesToUpdate[nodesToUpdate.length - 2];
                var edges = network.body.data.edges.getIds(); //get all edges
                var targetEdgeId;
    
                for(var i = 0; i < edges.length; i++){ //loop through edges
                    if(StopSimulation == true){
                        resetEdgeColors().then(() => {
                            resetNodeColors()
                            .then(() => resolve());
                        });
                        return;
                    }
                    var edge = network.body.data.edges.get(edges[i]); //get a specific edge object by id
                    //console.log("Edge from:", edge.from); //debug
                    //console.log("Edge to:", edge.to); //debug
                    if((edge.from == startNode && edge.to == endNode) || (edge.from == endNode && edge.to == startNode)){ //check if edge is between start and end node
                        targetEdgeId = edge.id; //save edge id
                        break;
                    };
                };
                //console.log("Target edge:", targetEdgeId); //debug
                network.body.data.edges.update({ id: targetEdgeId, color: EdgeColor }); //update edge color
            }
    
            //console.log("Nodes to update:", nodesToUpdate); //debug
            setTimeout(animate, delay); //recursively call animate()
        }
        animate(); //start animation
    });
}

function RefrencedNodesCW(nodeID){ //function will return nodes that are connected (refrenced) to the current selected node in clockwise direction
    var refrencedNodes = []; //IDs of all refrenced nodes
    var k = Math.floor(Math.log2(N)); //maximum value of k
    var NodeRef;

    for(var i = 0; i < k; i++){
        if(StopSimulation == true){
            resetEdgeColors().then(() => {
                resetNodeColors();
            })
            return refrencedNodes;
        }
        NodeRef = ((nodeID + Math.pow(2, i)) % N); 
        if(NodeRef != nodeID){ //additional check to avoid self loops, otherwise when N has value 2^n it will create looped connection around every node
            refrencedNodes.push(NodeRef);
        }
    }
    return refrencedNodes; //return array of refrenced nodes
}


function RefrencedNodesCCW(nodeID){ //function will return nodes that are connected (refrenced) to the current selected node in counterclockwise direction
    var refrencedNodes = []; //IDs of all refrenced nodes
    var k = Math.floor(Math.log2(N)); //maximum value of k
    var NodeRef;

    for(var i = 0; i < k; i++){
        if(StopSimulation == true){
            resetEdgeColors().then(() => {
                resetNodeColors();
            })
            return refrencedNodes;
        }
        NodeRef = ((nodeID - Math.pow(2, i)) + N) % N;
        if(NodeRef != nodeID){ //additional check to avoid self loops, otherwise when N has value 2^n it will create looped connection around every node
            refrencedNodes.push(NodeRef);
        } 
    }
    return refrencedNodes; //return array of refrenced nodes
}

function NodeDistance(RefNodeCW, RefNodeCCW, endNode){ //following function returns node distances in clockwise and counterclockwise direction

    var CWdistance = []; //array for node distance in clockwise direction
    var CCWdistance = []; //array for node distance in counterclockwise direction
    var distanceTemp = 0;

    for(var i = 0; i < RefNodeCW.length; i++){ //calculate distance in clockwise direction
        if(StopSimulation == true){
            resetEdgeColors().then(() => {
                resetNodeColors();
            })
            return;
        }
        distanceTemp = (endNode - RefNodeCW[i] + N) % N;
        CWdistance.push([RefNodeCW[i], distanceTemp]); //save node id and distance in clockwise direction
    }

    for(var i = 0; i < RefNodeCCW.length; i++){ //calculate distance in counterclockwise direction
        if(StopSimulation == true){
            resetEdgeColors().then(() => {
                resetNodeColors();
            })
            return;
        }
        distanceTemp = (RefNodeCCW[i] - endNode + N) % N;
        CCWdistance.push([RefNodeCCW[i], distanceTemp]); //save node id and distance in counterclockwise direction
    }

 
    var minNodeCw = CWdistance[0];
    for (var i = 1; i < CWdistance.length; i++) { //find the node with the minimum distance in the CW direction
        if (CWdistance[i][1] < minNodeCw[1]) {
            minNodeCw = CWdistance[i];
        }
    }
    var minDistanceCW = minNodeCw[1];


    var minNodeCCW = CCWdistance[0];
    for (var i = 1; i < CCWdistance.length; i++) { //find the node with the minimum distance in the CCW direction
        if (CCWdistance[i][1] < minNodeCCW[1]) {
            minNodeCCW = CCWdistance[i];
        }
    }
    var minDistanceCCW = minNodeCCW[1];

    return{ //return node distances in both clockwise and counterclockwise direction in an object
        CW: {node: minNodeCw[0], distance: minDistanceCW},
        CCW: {node: minNodeCCW[0], distance: minDistanceCCW}
    }

}

function resetEdgeColors(){ //following function resets all edge colors to default color
    return new Promise((resolve, reject) => {
        //console.log("resetEdgeColors() is called");
        var edges = network.body.data.edges.getIds();
        var resetColor = {color: '#f2f2f2'};
        var edgesToUpdate = [];

        edges.forEach(function(edgeID){
            edgesToUpdate.push({id: edgeID, color: resetColor});
        });

        network.body.data.edges.update(edgesToUpdate);
        resolve();
    });
}


function loopRingAnimation(){ //following function loops the ring animation until stop button is pressed
    return new Promise((resolve, reject) => {
        resetEdgeColors().then(() => { //reset edge colors
            resetNodeColors().then(() => { //reset node colors
                if(StopSimulation == false){
                    RingAnimation() //if stop button is not pressed, call ring animation 
                        .then(() => loopRingAnimation()) //repeat the loop
                        .catch(error => reject(error));
                }
                else{
                    resetNodeColors().then(() => resolve());
                }
            })
        })
    });
}



//------------------------------------------------------------------------------------------------------------------------------------------------------------//


