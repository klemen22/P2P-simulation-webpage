const express = require("express"); //web framework for NodeJS
const app = express(); //create express application
const cors = require("cors"); //enable CORS (Cross Origin Resource Sharing)
const mysql = require("mysql2"); //mysql module for NodeJS
const bcrypt = require("bcrypt"); //module for hashing and comparing passwords
const port = 3001; //port number where the server will listen

app.use(cors()); //enable CORS for cross origin requests
app.use(express.json()); //parse JSON requests

const connection = mysql.createPool({ //swicthed from mysql.createConnection() to mysql.createPool() for managing multiple connections
    host: "localhost",
    user: "root",
    database: "project",
    waitForConnections: true, //enable queueing
    connectionLimit: 10, //maximum number of connections
    queueLimit: 0 //no limit on number of queued connections
});

//initial connection was removed for debugging purposes

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//------------------------------------------------------------------Fetch-Data-------------------------------------------------------------------------------//

app.get("/api/addresses", (req, res) => { //endpoint for fetching IP addresses
    const { ip, start, end, page = 1, itemsPerPage = 10 } = req.query; //retrieve query parameters from request
    const offset = (parseInt(page, 10) - 1) * parseInt(itemsPerPage, 10); //calculate offset for pagination
    const limit = parseInt(itemsPerPage, 10); //number of items per page

    let query = "SELECT * FROM addresses WHERE 1=1"; //build SQL query with filters //1=1 is a placeholder
    let queryParams = [];

    if (ip) { //add filter for IP address
        query = query + " AND ipAddress LIKE ?";
        queryParams.push(`%${ip}%`);
    }
    if (start) { //add filter for start time
        query = query + " AND timeStamp >= ?";
        queryParams.push(start);
    }
    if (end) { //add filter for end time
        const endDate = new Date(end); 
        endDate.setHours(23, 59, 59, 999); //adjust end date so it includes all hours, minutes, seconds, and milliseconds on that day
        query = query + " AND timeStamp <= ?";
        const formattedEndDate = endDate.toLocaleString('sv-SE', { hour12: false }).replace('T', ' '); //use ISO 8601 format and replace T with space so it matches MySQL format
        queryParams.push(formattedEndDate);  
    }

    query = query + " LIMIT ? OFFSET ?"; //add pagination
    queryParams.push(limit, offset);

    connection.getConnection((err, connection) => { //get connection from pool and execute query // "(err, connection) => {" is the same as "function (err, connection) {"
        if (err) { //handle error
            console.error("Error getting connection from pool:", err); //debug
            return res.status(500).send("Error getting connection");
        }

        connection.query(query, queryParams, (err, results) => { //execute query
            if (err) { //handle error
                console.error("Error fetching data:", err);
                connection.release(); 
                return res.status(500).send("Error fetching data");
            }

            const countQuery = "SELECT COUNT(*) AS total FROM addresses WHERE 1=1" + //build count query for total matching rows
                (ip ? " AND ipAddress LIKE ?" : "") +
                (start ? " AND timeStamp >= ?" : "") +
                (end ? " AND timeStamp <= ?" : "");

            const countParams = queryParams.slice(0, -2); //remove limit and offset from count query //remove pagination parameters

            connection.query(countQuery, countParams, (countErr, countResults) => { //execute count query
                connection.release();  //release connection

                if (countErr) { //handle error
                    console.error("Error fetching count:", countErr); //debug
                    return res.status(500).send("Error fetching data");
                }

                const totalItems = countResults[0].total; //get total number of matching rows
                const totalPages = Math.ceil(totalItems / itemsPerPage); //calculate total number of pages

                res.json({ //return results as JSON
                    results,
                    currentPage: page,
                    totalPages
                });
            });
        });
    });
});

app.listen(port, () => { //start server and listen to the specified port
    console.log(`Server listening on port ${port}`); //debug
});

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------------Login---------------------------------------------------------------------------------//

app.post("/api/login", (req, res) => { //endpoint for login
    const { email, password } = req.body; //retrieve query parameters from request

    connection.query("SELECT * FROM users WHERE email = ?", [email], (err, results) => { //query database for user
        if(err){ //process error
            console.error("Error fetching data:", err);
            return res.status(500).send("Error logging in");
        }

        if(results.length === 0) { // if length is 0 then user wasn't found
            return res.status(401).send("Invalid email or password");
        }

        const user = results[0]; //get user from results

        bcrypt.compare(password, user.password, (bcryptErr, bcryptRes) => { //compare provided password with stored hashed password
            if(bcryptErr) { //handle error
                console.error("Error comparing passwords:", bcryptErr); //debug
                return res.status(500).send("Error logging in");
            }

            if(!bcryptRes) { //if passwords don't match //bcryptRes is a boolean value
                return res.status(401).send("Invalid email or password");
            }

            res.send("Login successful"); //send success message
        });
    });
});


//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------------Register------------------------------------------------------------------------------//

app.post("/api/register", (req, res) => { //endpoint for registration
    const { firstName, lastName, birthDate, email, password } = req.body; //retrieve query parameters from request

    connection.query("SELECT * FROM register WHERE email = ?", [email], (err, results) => { //query database to check if email already exists
        if (err) { //handle error
            console.error("Error fetching data:", err); //debug
            return res.status(500).send("Error registering");
        }

        if (results.length > 0) { //if results length is greater than 0 then email entry already exists
            return res.status(409).send("Email already exists"); //send error message and return
        }

        bcrypt.hash(password, 10, (err, hashedPassword) => { //hash password using bcrypt
            if (err) { //handle error
                console.error("Error hashing password:", err); //debug
                return res.status(500).send("Error registering user");
            }
    
            const query = "INSERT INTO register (firstName, lastName, birthDate, email, password) VALUES (?, ?, ?, ?, ?)"; //create SQL query to insert data into "register" table
            connection.query(query, [firstName, lastName, birthDate, email, hashedPassword], (err) => { //execute query
                if (err) { //handle error
                    console.error("Error registering user:", err);
                    return res.status(500).send("Error registering user");
                }
                res.send("Registration successful"); //send success message
            });
        });
    });
});

//------------------------------------------------------------------------------------------------------------------------------------------------------------//