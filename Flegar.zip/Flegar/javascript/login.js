//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------Event-Listeners-----------------------------------------------------------------------------//

document.addEventListener("DOMContentLoaded", function() { //when the document is loaded //setup event listener when DOM is loaded
    var loginButton = document.getElementById("loginButton"); //variable for login button

    loginButton.addEventListener("click", function() { //event listener for login button
        //console.log("Login button is clicked");//debug
        var email = document.getElementById("email").value; //fetch email
        var password = document.getElementById("password").value; //fetch password
        login(email, password); //call login function with email and password
    });
});

//------------------------------------------------------------------------------------------------------------------------------------------------------------//

function login (email, password) {
    //console.log("Login() was called"); //debug

    var alertMessage = document.getElementById("alertMessage"); //retrieve alert message element from HTML

    alertMessage.innerHTML = ""; //clear all previous alerts

    if(!emailValidation(email)) { //call email validation function to check if email is valid
        alertMessage.innerHTML = "Invalid email address"; //if email is not valid, display error message and return
        return;
    }

    if(!password) { //check if password is empty
        alertMessage.innerHTML = "Please enter a password"; //if password is empty, display error message and return
        return;
    }


    fetch ("http://localhost:3001/api/login", { //make a POST request
        method: "POST", //specify POST method
        headers: {
            "Content-Type": "application/json" //specify JSON content type
        },
        body: JSON.stringify({ //convert email and password to JSON string
            email: email,
            password: password
        })
    })
    .then(response => response.text()) //convert response to text
    .then(text => {
        //console.log(text); //debug
        if(text == "Login successful") { //handle the reponse text
            //console.log("Redirecting to test.html"); //debug
            window.location.href = "html/test.html"; //if login is successful, redirect to test.html
        }
        if(text == "Invalid email or password") {
            alertMessage.innerHTML = text;
        }
    })
    .catch(error => {
        console.error("Error:", error); //debug
    });
}

function emailValidation(email) { //following function checks if email is valid
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email); //function returns true if email is valid or false if not
}

