const mysql = require("mysql2"); //mysql module for NodeJS
const readline = require("readline"); //import readline module for reading user input from console

const connection = mysql.createPool({ //create connection to MySQL database
    host: "localhost",
    user: "root",
    database: "project",
    waitForConnections: true, //enable queueing
    connectionLimit: 10, //maximum number of connections
    queueLimit: 0 //no limit on number of queued connections
});

const rl = readline.createInterface({ //create readline interface
    input: process.stdin, //standard input stream
    output: process.stdout //standard output stream
});

function listUsers(){ //following function retrieves data from MySQL database and prints out the results to the console
    return new Promise((resolve, reject) => {
        const query = "SELECT * FROM register"; //create SQL query to fetch all data from "register" table
        
        connection.getConnection((err, conn) => { //get connection from pool
            if (err) { //handle error
                console.log("Error getting connection from pool:", err); //debug
                reject(err); //reject the promise in case of error
                return;
            }

            conn.query(query, (err, results) => {
                conn.release(); //release connection back to the pool
                if (err) {
                    console.log("Error fetching data:", err); //debug
                    reject(err); //reject the promise in case of error
                    return;
                }

                console.log("Registered users:"); //print header
                results.forEach((user, index) => { //loop through results
                    console.log(`${index + 1}. ${user.firstName} ${user.lastName} (${user.email})`); //print result
                });
                resolve(results); //resolve the promise with results
            });
        });
    });
}

function selectUser(users){ //following function prompts the user to select a user to authorize by ID
    return new Promise((resolve, reject) => {
        rl.question("Enter user ID to authorize: ", (id) => { //prompt user to enter user ID
            const index = parseInt(id) - 1;

            if (index >= 0 && index < users.length) { //check if user ID is valid
                const selectedUser = users[index]; //get selected user

                authorizeUser(selectedUser.email).then(() => { //call authorizeUser function with selected user email
                    console.log("User has been authorized"); //debug
                    rl.close(); //close readline interface after authorization
                    resolve(); //resolve the promise
                })
                .catch((err) => {
                    //console.log("Error during authorization:", err); //debug
                    rl.close(); //close readline interface in case of error
                    reject(err); //reject the promise
                });
            } else {
                //console.log("Invalid user ID"); //debug
                rl.close(); //close readline interface in case of invalid ID
                reject("Invalid user ID"); //reject the promise
            }
        });
    });
}

function authorizeUser(email) { //following functions inserts selected user data to "users" table
    return new Promise((resolve, reject) => {
        connection.getConnection((err, conn) => { //get connection from pool
            if (err) { //handle error
                console.log("Error getting connection from pool:", err); //debug
                reject(err); //reject the promise in case of error
                return;
            }

            const checkUserQuery = "SELECT * FROM users WHERE email = ?"; //create SQL query to check if email already exists in "users" table
            conn.query(checkUserQuery, [email], (err, userResults) => { //execute query
                if (err) { //handle error
                    console.log("Error checking users table:", err); //debug
                    conn.release(); //release connection in case of error
                    reject(err); //reject the promise in case of error
                    return;
                }

                if (userResults.length > 0) { //if length is greater than 0 then email already exists
                    conn.release(); //release connection if email already exists
                    reject("User with this email already exists"); //reject the promise if email already exists
                    return;
                }

                const registerQuery = "SELECT * FROM register WHERE email = ?"; //create SQL query to fetch user data from "register" table
                conn.query(registerQuery, [email], (err, registerResults) => { //execute query
                    if (err) { //handle error
                        console.log("Error fetching data from register table:", err); //debug
                        conn.release(); //release connection in case of error
                        reject(err); //reject the promise in case of error
                        return;
                    }

                    const user = registerResults[0]; //get user data from results
                    if (!user) { //if user is not found
                        conn.release(); //release connection if no user found
                        reject("User not found in register table"); //reject the promise if no user was found
                        return;
                    }

                    const insertQuery = "INSERT INTO users (email, password) VALUES (?, ?)"; //create SQL query to insert user data into "users" table
                    conn.query(insertQuery, [user.email, user.password], (err) => { //execute query
                        conn.release(); //release connection after insert
                        if (err) { //handle error
                            console.log("Error inserting data:", err); //debug
                            reject(err); //reject the promise in case of error
                            return;
                        }
                        resolve(); //resolve the promise after successful insertion
                    });
                });
            });
        });
    });
}


function main(){ //following function is the main function that calls all other functions in sequence
    listUsers().then((users) => { //list all users
        return selectUser(users); //prompt user to select a user to authorize
    })
    .then(() => {
        console.log("User authorization process completed."); //debug
    })
    .catch((err) => { //handle error
        console.log("Error:", err);
    })
    .finally(() => { //finally close the readline interface and exit the program
        rl.close(); //close readline interface
        //console.log("Closing program."); //debug
        process.exit(); //exit the program
    });
}

main(); //call main function
