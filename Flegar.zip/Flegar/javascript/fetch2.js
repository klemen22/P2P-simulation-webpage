let ipAddresses = []; 
let filtered_ipAdresses = [];

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------Fetching-data-------------------------------------------------------------------------------//

function fetchData() { //following function is used for fetching data line by line so it bypases improper .json format from Tshark output ([] are missing and irrelevant metadata is present)
    return new Promise((resolve, reject) => {
        fetch('../captured_packets/capture.json') //built-in javascript function used for retrieving data in this case .json file
            .then(response => { //fetch is based on promise and returns response object
                const reader = response.body.getReader(); //built-in javascript function used for reading from the stream
                let decoder = new TextDecoder(); //built-in javascript interface used for decoding stream into a string
                let buffer = ''; //simple buffer
                return reader.read().then(function processText({ done, value }) {
                    if (done) { //check if all data has been read
                        resolve(); 
                        return;
                    }
                    buffer = buffer + decoder.decode(value, { stream: true }); //decode is part of TextDecoder interface used for decoding stream into a string
                    const lines = buffer.split('\n'); //divide buffer into lines (array)
                    buffer = lines.pop(); //remove last line
                    lines.forEach(line => { //forEach is built-in javascript function used for iterating over array it's the same as for loop
                        if (!line.startsWith('{"index":')) { //skip lines that start with valid json format
                            const jsonData = JSON.parse(line); //convert json string to js object
                            const ipAddress = jsonData.layers.ip_dst[0];
                            ipAddresses.push(ipAddress);
                        }
                    });
                    //console.log(ipAddresses);
                    filtering();
                    return reader.read().then(processText); //continue loop
                });
            })
            .catch(error => {
                console.error('Error fetching and processing JSON:', error); //console error is the same as console.log but for errors
                reject(error); 
            });
    });
}


function filtering(){ //following function filters out host device ip address and duplicates
    for(i = 0; i < ipAddresses.length; i++){
        if(ipAddresses[i] != "192.168.64.95"){ //filter out host device ip address //change to IP address of your device
            filtered_ipAdresses.push(ipAddresses[i]);
        }
    }

    for(i = 0; i < filtered_ipAdresses.length; i++){
        for(j = i + 1; j < filtered_ipAdresses.length; j++){
            if(filtered_ipAdresses[i] == filtered_ipAdresses[j]){
                filtered_ipAdresses.splice(j, 1); //remove duplicates
            }
        }    
    }
    //console.log("Filtrirana tabela:");
    //console.log(filtered_ipAdresses);
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------Draw-nodes----------------------------------------------------------------------------------//

function DrawHost(){ //main function for drawing nodes
    //console.log("DrawHost() was callled"); //debug
    fetchData().then(() => { 
        var nodesMain = new vis.DataSet([ //initialize nodes and edges
            { id: 1, label: 'Me' }
        ])
        var edgesMain = new vis.DataSet([]);

        var container = document.getElementById('container2');
        var data = { nodes: nodesMain, edges: edgesMain }; //object with nodes and edges
        var options = { //object with options for network (part of the vis.js library)
            autoResize: true,
            height: '100%',
            width: '100%',
            nodes: {
                size: 10,
                borderWidth: 2,
                borderWidthSelected: 2,
                color: {
                   background: '#FFFFFF',
                   border: '#FFFFFF',
                   highlight: {
                    border: '#1e90ff',
                    background: '#a6c1ee'
                   } 
                },
                shadow:{
                    enabled: true,
                    size: 8,
                    color: '#d9d9d9'
                },
            },
            physics: {
                enabled: true,
                solver: 'forceAtlas2Based',
                forceAtlas2Based: {
                    springLength: 100,
                    springConstant: 0.1,
                    damping: 0.4,
                    avoidOverlap: 0.1
                },
                stabilization: {
                    enabled: false,
                    fit: true
                }
            }
        };
  
        var network = new vis.Network(container, data, options); //initialize network with container id, data and options

        var delay = 400;
        var counter = 0;

        for (let i = 0; i < filtered_ipAdresses.length; i++) { //draw nodes and edges with delay
            setTimeout(() => {
                var newNode = { id: i + 2, label: filtered_ipAdresses[i], color:{
                    background: '#f2f2f2',
                    border: '#f2f2f2',
                    highlight: {
                        background: '#a6c1ee',
                        border: '#1e90ff'
                    }
                },
                    shadow:{
                    enabled: true,
                    size: 6,
                    color: '#d9d9d9'
                },
                borderWidth: 2,
                borderWidthSelected: 2,
            };
                nodesMain.add(newNode); //add new node

                var newEdge = { from: 1, to: i + 2, color:{
                    color: '#f2f2f2'
                },
                length: 300
             };
                edgesMain.add(newEdge); //add new edge

                if(i == filtered_ipAdresses.length - 1){ //fit network after all nodes and edges are drawn 
                    network.fit({
                        animation: {
                            duration: 1000,
                            easingFunction: 'easeInOutQuad'
                        }
                    })
                }

            }, counter);
            counter += delay;
        }
    });
}

function updateGraph() { //function for updating graph by calling DrawHost() and resetting ipAddresses and filtered_ipAdresses
    //console.log("Update");
    ipAddresses = [];
    filtered_ipAdresses = [];
    DrawHost();
}
setInterval(updateGraph, 1.8e+6); //update graph every half an hour

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------Event-Listeners-----------------------------------------------------------------------------//

document.addEventListener("DOMContentLoaded", function() { //event listener for DOMContentLoaded - basically when page is loaded
    var RefreshButton = document.getElementById("RefreshButton"); //variable for refresh button
    var HistoryButton = document.getElementById("HistoryButton"); //variable for history button

    DrawHost(); //initial draw

    RefreshButton.addEventListener("click", function() { //event listener for refresh button
        updateGraph(); //update graph early
        //console.log("Refresh button is clicked");//debug
    });

    HistoryButton.addEventListener("click", function() { //event listener for history button
        //console.log("History button is clicked");//debug
        window.location.href = "../html/history.html"; //redirect to history page
    });
});

//------------------------------------------------------------------------------------------------------------------------------------------------------------//


