const fs = require("fs"); // file system module
const path = require("path"); // file path module
const mysql = require("mysql2"); // mysql module for connecting and interacting with MySQL database
const { TextDecoder } = require("text-encoding"); // text encoding module for data fetching
var interval = 12 * 3.6e+6; //delay for 12 hours in milliseconds

let ipAddresses = []; //initialize ipAddresses array
let filtered_ipAdresses = [];

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//---------------------------------------------------------------Fetching-data-------------------------------------------------------------------------------//

//read JSON file directly in NodeJS
function fetchData() {
    return new Promise((resolve, reject) => { //following function reads data from JSON file with specified path
        const filePath = "../captured_packets/capture.json";
        fs.readFile(filePath, "utf8", (err, data) => { //read file  //"(err, data) => {" is the same as "function (err, data) {"
            if (err) { //handle error
                console.error("Error reading file:", err); //debug
                return reject(err);
            }
            
            let buffer = data; //store data in buffer
            processData(buffer); //call processData function with buffer as an argument
            resolve();
        });
    });
}

function processData(buffer) {
    const lines = buffer.split("\n"); // split buffer by new line
    lines.forEach(line => { //loop through each line to extract IP addresses
        if (line.trim() && !line.startsWith('{"index":')) { //ignore empty lines and index lines
            try {
                const jsonData = JSON.parse(line); //parse each line as JSON
                const ipAddress = jsonData.layers.ip_dst[0]; //extract destination IP address
                ipAddresses.push(ipAddress); //add IP address to ipAddresses array
            } catch (error) {
                console.error("Error parsing JSON:", error); //debug
            }
        }
    });

    filtering(); //call filtering function for filtering out specific IP addresses
}

function filtering(){ //following function filters out duplicate IP addresses and host IP address
    filtered_ipAdresses = [];

    for(i = 0; i < ipAddresses.length; i++){ //filter out host IP
        if(ipAddresses[i] != "192.168.64.95"){ //local host IP address //change to IP address of your device
            filtered_ipAdresses.push(ipAddresses[i]);
        }
    }

    for(i = 0; i < filtered_ipAdresses.length; i++){ //filter out duplicates
        for(j = i + 1; j < filtered_ipAdresses.length; j++){
            if(filtered_ipAdresses[i] == filtered_ipAdresses[j]){
                filtered_ipAdresses.splice(j, 1);
            }
        }    
    }
    //console.log("Filtrirana tabela:"); //debug
    console.log(filtered_ipAdresses);
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------//
//-----------------------------------------------------------------MySQL-------------------------------------------------------------------------------------//

const connection = mysql.createConnection({ //creating connection with MySQL database with database credentials
    host: "localhost",
    user: "root",
    database: "project"
});

connection.connect((err) => { //connect to database
    if (err) { //handle error
        console.error("Error connecting to database:", err); //debug
    } else {
        console.log("Connected to database"); //debug
    }
    //insertAddress("192.168.64.1"); // test address insert

    fetchData().then(() => { //fetch data and insert into database
        //console.log("Fetching data is done"); // debug
        insertAddress(filtered_ipAdresses, connection); //insert filtered data into database
    });
});

function insertAddress(ipAddresses, connection){ //following function inserts data into MySQL database
    if (ipAddresses.length === 0) { //check if there are any IP addresses to insert
        //console.log("No IP addresses to insert."); //debug    
        connection.end(); //if there are no IP addresses to insert, disconnect from database
        return;
    }

    const query = "INSERT INTO addresses (ipAddress, timeStamp) VALUES ?"; //SQL query to insert data into "addresses" table with timestamp
    const values = ipAddresses.map((ip) => [ip, new Date()]); //prepare data to insert

    connection.query(query, [values], (err, result) => { //execute query
        if (err){ //handle error
            console.error("Error inserting data:", err);
        } else {
            console.log("Data inserted successfully", result);
        }

        connection.end(err => { //disconnect from database
            if (err) {
                console.error("Error disconnecting from database:", err);
            } else {
                console.log("Disconnected from database");
            }
        });
    });
}

function processAndInsert(){ //following function processes data and inserts it into MySQL database repeatedly based on the interval below//basically loops the code above
    const connection =  Connection({ //creating connection with MySQL database with database credentials
        host: "localhost",
        user: "root",
        database: "project"
    });

    connection.connect((err) => { //connect to database
        if (err) { //handle error
            console.error("Error connecting to database:", err); //debug
        } else {
            console.log("Connected to database"); //debug
            fetchData().then(() => { //fetch data and insert into database
                console.log("Fetching data is done"); // debug
                insertAddress(filtered_ipAdresses, connection); //insert filtered data into database with timestamp
            });
        }
    });
}

setInterval(processAndInsert, interval); //set interval to processAndInsert function

//------------------------------------------------------------------------------------------------------------------------------------------------------------//

